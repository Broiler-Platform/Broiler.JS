# Bundle sjl-5-001's reference-arm comparison, classified

80013 differences: 63628 (a), 3158 (c), 13227 unclassified.

## FromHex, J:FromHex and SetFromHex: (a), 11036

correction of Broiler.JS: S is the reference's; B1.

- `B1H:16` 0 input `0g`: S `read:0|written:0|bytes:-`, arm `error:SyntaxError|bytes:-`
- `B1H:17` 0 input `0Z`: S `read:0|written:0|bytes:-`, arm `error:SyntaxError|bytes:-`
- `B1H:18` 0 input `0\u005Cu0020`: S `read:0|written:0|bytes:-`, arm `error:SyntaxError|bytes:-`
- `B1H:25` 0 input `9g`: S `read:0|written:0|bytes:-`, arm `error:SyntaxError|bytes:-`
- `B1H:26` 0 input `9Z`: S `read:0|written:0|bytes:-`, arm `error:SyntaxError|bytes:-`
- `B1H:27` 0 input `9\u005Cu0020`: S `read:0|written:0|bytes:-`, arm `error:SyntaxError|bytes:-`
- `B1H:34` 0 input `ag`: S `read:0|written:0|bytes:-`, arm `error:SyntaxError|bytes:-`
- `B1H:35` 0 input `aZ`: S `read:0|written:0|bytes:-`, arm `error:SyntaxError|bytes:-`
- `B1H:36` 0 input `a\u005Cu0020`: S `read:0|written:0|bytes:-`, arm `error:SyntaxError|bytes:-`
- `B1H:43` 0 input `fg`: S `read:0|written:0|bytes:-`, arm `error:SyntaxError|bytes:-`
- `B1H:44` 0 input `fZ`: S `read:0|written:0|bytes:-`, arm `error:SyntaxError|bytes:-`
- `B1H:45` 0 input `f\u005Cu0020`: S `read:0|written:0|bytes:-`, arm `error:SyntaxError|bytes:-`
- `B1H:52` 0 input `Ag`: S `read:0|written:0|bytes:-`, arm `error:SyntaxError|bytes:-`
- `B1H:53` 0 input `AZ`: S `read:0|written:0|bytes:-`, arm `error:SyntaxError|bytes:-`
- `B1H:54` 0 input `A\u005Cu0020`: S `read:0|written:0|bytes:-`, arm `error:SyntaxError|bytes:-`
- `B1H:61` 0 input `Fg`: S `read:0|written:0|bytes:-`, arm `error:SyntaxError|bytes:-`
- `B1H:62` 0 input `FZ`: S `read:0|written:0|bytes:-`, arm `error:SyntaxError|bytes:-`
- `B1H:63` 0 input `F\u005Cu0020`: S `read:0|written:0|bytes:-`, arm `error:SyntaxError|bytes:-`
- `B1H:64` 0 input `g0`: S `read:0|written:0|bytes:-`, arm `error:SyntaxError|bytes:-`
- `B1H:65` 0 input `g9`: S `read:0|written:0|bytes:-`, arm `error:SyntaxError|bytes:-`

## GetSubstitution, J:JSRegExp.Replace(string, string): (a), 43548

correction of Broiler.JS: S is the reference's; S3.

- `S1E:230` 0/-/groups/start input `$<>`: S `str:`, arm `str:$<>`
- `S1E:230` 0/-/groups/middle input `$<>`: S `str:`, arm `str:$<>`
- `S1E:230` 0/-/groups/end input `$<>`: S `str:`, arm `str:$<>`
- `S1E:230` 1/defined/groups/start input `$<>`: S `str:`, arm `str:$<>`
- `S1E:230` 1/defined/groups/middle input `$<>`: S `str:`, arm `str:$<>`
- `S1E:230` 1/defined/groups/end input `$<>`: S `str:`, arm `str:$<>`
- `S1E:230` 1/undefined/groups/start input `$<>`: S `str:`, arm `str:$<>`
- `S1E:230` 1/undefined/groups/middle input `$<>`: S `str:`, arm `str:$<>`
- `S1E:230` 1/undefined/groups/end input `$<>`: S `str:`, arm `str:$<>`
- `S1E:230` 1/empty/groups/start input `$<>`: S `str:`, arm `str:$<>`
- `S1E:230` 1/empty/groups/middle input `$<>`: S `str:`, arm `str:$<>`
- `S1E:230` 1/empty/groups/end input `$<>`: S `str:`, arm `str:$<>`
- `S1E:230` 2/defined/groups/start input `$<>`: S `str:`, arm `str:$<>`
- `S1E:230` 2/defined/groups/middle input `$<>`: S `str:`, arm `str:$<>`
- `S1E:230` 2/defined/groups/end input `$<>`: S `str:`, arm `str:$<>`
- `S1E:230` 2/undefined/groups/start input `$<>`: S `str:`, arm `str:$<>`
- `S1E:230` 2/undefined/groups/middle input `$<>`: S `str:`, arm `str:$<>`
- `S1E:230` 2/undefined/groups/end input `$<>`: S `str:`, arm `str:$<>`
- `S1E:230` 2/empty/groups/start input `$<>`: S `str:`, arm `str:$<>`
- `S1E:230` 2/empty/groups/middle input `$<>`: S `str:`, arm `str:$<>`

## JSON parse, J:JSJSON.Parse: (a), 2816

correction of Broiler.JS: S is the reference's; J1.

- `J1R:18` - input `(1972 characters)`: S `(3102 characters)`, arm `error:SyntaxError`
- `J1R:26` - input `(2260 characters)`: S `(3630 characters)`, arm `error:SyntaxError`
- `J1R:27` - input `(2260 characters)`: S `(3630 characters)`, arm `error:SyntaxError`
- `J1R:30` - input `(1726 characters)`: S `(2943 characters)`, arm `error:SyntaxError`
- `J1R:46` - input `(2338 characters)`: S `(3867 characters)`, arm `error:SyntaxError`
- `J1R:100` - input `(1450 characters)`: S `(2359 characters)`, arm `error:SyntaxError`
- `J1R:112` - input `(1871 characters)`: S `(3049 characters)`, arm `error:SyntaxError`
- `J1R:114` - input `(1539 characters)`: S `(2486 characters)`, arm `error:SyntaxError`
- `J1R:118` - input `(2099 characters)`: S `(3362 characters)`, arm `error:SyntaxError`
- `J1R:134` - input `(2326 characters)`: S `(3703 characters)`, arm `error:SyntaxError`
- `J1R:135` - input `(2325 characters)`: S `(3702 characters)`, arm `error:SyntaxError`
- `J1R:138` - input `(1877 characters)`: S `(3025 characters)`, arm `error:SyntaxError`
- `J1R:144` - input `(2045 characters)`: S `(3220 characters)`, arm `error:SyntaxError`
- `J1R:150` - input `(1337 characters)`: S `(2266 characters)`, arm `error:SyntaxError`
- `J1R:156` - input `(2327 characters)`: S `(3869 characters)`, arm `error:SyntaxError`
- `J1R:158` - input `(1645 characters)`: S `(2699 characters)`, arm `error:SyntaxError`
- `J1R:180` - input `(1209 characters)`: S `(1918 characters)`, arm `error:SyntaxError`
- `J1R:184` - input `(1385 characters)`: S `(2279 characters)`, arm `error:SyntaxError`
- `J1R:268` - input `(1715 characters)`: S `(2776 characters)`, arm `error:SyntaxError`
- `J1R:300` - input `(2400 characters)`: S `(3923 characters)`, arm `error:SyntaxError`

## JSON parse, J:JSJSON.Parse: (a), 4096

correction of Broiler.JS: S is the reference's; J2.

- `J1S:155901` - input `"\u005Cu005CuD800"`: S `json:str:\u005CuD800`, arm `error:SyntaxError`
- `J1S:155902` - input `"\u005Cu005Cud800"`: S `json:str:\u005CuD800`, arm `error:SyntaxError`
- `J1S:155904` - input `"\u005Cu005CuD801"`: S `json:str:\u005CuD801`, arm `error:SyntaxError`
- `J1S:155905` - input `"\u005Cu005Cud801"`: S `json:str:\u005CuD801`, arm `error:SyntaxError`
- `J1S:155907` - input `"\u005Cu005CuD802"`: S `json:str:\u005CuD802`, arm `error:SyntaxError`
- `J1S:155908` - input `"\u005Cu005Cud802"`: S `json:str:\u005CuD802`, arm `error:SyntaxError`
- `J1S:155910` - input `"\u005Cu005CuD803"`: S `json:str:\u005CuD803`, arm `error:SyntaxError`
- `J1S:155911` - input `"\u005Cu005Cud803"`: S `json:str:\u005CuD803`, arm `error:SyntaxError`
- `J1S:155913` - input `"\u005Cu005CuD804"`: S `json:str:\u005CuD804`, arm `error:SyntaxError`
- `J1S:155914` - input `"\u005Cu005Cud804"`: S `json:str:\u005CuD804`, arm `error:SyntaxError`
- `J1S:155916` - input `"\u005Cu005CuD805"`: S `json:str:\u005CuD805`, arm `error:SyntaxError`
- `J1S:155917` - input `"\u005Cu005Cud805"`: S `json:str:\u005CuD805`, arm `error:SyntaxError`
- `J1S:155919` - input `"\u005Cu005CuD806"`: S `json:str:\u005CuD806`, arm `error:SyntaxError`
- `J1S:155920` - input `"\u005Cu005Cud806"`: S `json:str:\u005CuD806`, arm `error:SyntaxError`
- `J1S:155922` - input `"\u005Cu005CuD807"`: S `json:str:\u005CuD807`, arm `error:SyntaxError`
- `J1S:155923` - input `"\u005Cu005Cud807"`: S `json:str:\u005CuD807`, arm `error:SyntaxError`
- `J1S:155925` - input `"\u005Cu005CuD808"`: S `json:str:\u005CuD808`, arm `error:SyntaxError`
- `J1S:155926` - input `"\u005Cu005Cud808"`: S `json:str:\u005CuD808`, arm `error:SyntaxError`
- `J1S:155928` - input `"\u005Cu005CuD809"`: S `json:str:\u005CuD809`, arm `error:SyntaxError`
- `J1S:155929` - input `"\u005Cu005Cud809"`: S `json:str:\u005CuD809`, arm `error:SyntaxError`

## JSON parse, J:JSJSON.Parse: (a), 2048

correction of Broiler.JS: S is the reference's; J3.

- `J1S:155903` - input `"\u005CuD800"`: S `json:str:\u005CuD800`, arm `exception:ArgumentException`
- `J1S:155906` - input `"\u005CuD801"`: S `json:str:\u005CuD801`, arm `exception:ArgumentException`
- `J1S:155909` - input `"\u005CuD802"`: S `json:str:\u005CuD802`, arm `exception:ArgumentException`
- `J1S:155912` - input `"\u005CuD803"`: S `json:str:\u005CuD803`, arm `exception:ArgumentException`
- `J1S:155915` - input `"\u005CuD804"`: S `json:str:\u005CuD804`, arm `exception:ArgumentException`
- `J1S:155918` - input `"\u005CuD805"`: S `json:str:\u005CuD805`, arm `exception:ArgumentException`
- `J1S:155921` - input `"\u005CuD806"`: S `json:str:\u005CuD806`, arm `exception:ArgumentException`
- `J1S:155924` - input `"\u005CuD807"`: S `json:str:\u005CuD807`, arm `exception:ArgumentException`
- `J1S:155927` - input `"\u005CuD808"`: S `json:str:\u005CuD808`, arm `exception:ArgumentException`
- `J1S:155930` - input `"\u005CuD809"`: S `json:str:\u005CuD809`, arm `exception:ArgumentException`
- `J1S:155933` - input `"\u005CuD80A"`: S `json:str:\u005CuD80A`, arm `exception:ArgumentException`
- `J1S:155936` - input `"\u005CuD80B"`: S `json:str:\u005CuD80B`, arm `exception:ArgumentException`
- `J1S:155939` - input `"\u005CuD80C"`: S `json:str:\u005CuD80C`, arm `exception:ArgumentException`
- `J1S:155942` - input `"\u005CuD80D"`: S `json:str:\u005CuD80D`, arm `exception:ArgumentException`
- `J1S:155945` - input `"\u005CuD80E"`: S `json:str:\u005CuD80E`, arm `exception:ArgumentException`
- `J1S:155948` - input `"\u005CuD80F"`: S `json:str:\u005CuD80F`, arm `exception:ArgumentException`
- `J1S:155951` - input `"\u005CuD810"`: S `json:str:\u005CuD810`, arm `exception:ArgumentException`
- `J1S:155954` - input `"\u005CuD811"`: S `json:str:\u005CuD811`, arm `exception:ArgumentException`
- `J1S:155957` - input `"\u005CuD812"`: S `json:str:\u005CuD812`, arm `exception:ArgumentException`
- `J1S:155960` - input `"\u005CuD813"`: S `json:str:\u005CuD813`, arm `exception:ArgumentException`

## JSON parse, J:JSJSON.Parse: (c), 3158

S is not the reference's.

- `J1R:4` - input `(3864 characters)`: S `len:6289:sha256:6da2363590fab70b3fef7e17613e8f0f6d72cfb8bc3815f01b42ebc9a4401810`, arm `error:SyntaxError`
- `J1R:16` - input `(2661 characters)`: S `len:4272:sha256:02b2835da3d6fa09de32e13fad323d357f945747648a43a1759b3a7689cf5661`, arm `error:SyntaxError`
- `J1R:36` - input `(3729 characters)`: S `len:5854:sha256:7224d4f5d487267f93dacca122bf15991a095fc50817f61d66aba2b9a3f05d9e`, arm `error:SyntaxError`
- `J1R:38` - input `(3312 characters)`: S `len:5365:sha256:fea6bee0da5db608633455b89ce9332752ef3744bf1574a388e64c963f35dd29`, arm `error:SyntaxError`
- `J1R:39` - input `(3311 characters)`: S `len:5365:sha256:d786366364cf206f4f0d45f5b022845bd29c2ed4dacb92d4e08d72139a586e6c`, arm `error:SyntaxError`
- `J1R:40` - input `(3766 characters)`: S `len:6094:sha256:cf99b7b4ebf2cc1fdd61fc25f8669552c0a8fd22b7bfdb4cfc1f4979e592421f`, arm `error:SyntaxError`
- `J1R:48` - input `(3268 characters)`: S `len:5372:sha256:8c8765d8bc38fe5d60b787b1f2f973de6ef50c707b1b9b72b6baa7d70dc7eea5`, arm `error:SyntaxError`
- `J1R:54` - input `(3491 characters)`: S `len:5563:sha256:204e9883b012dc7b045a3205602d9f57fd1de88d5e499c816d1fdae7e0bb0301`, arm `error:SyntaxError`
- `J1R:68` - input `(2947 characters)`: S `len:4820:sha256:d509672d7dd13c03deb3dbedea9a64ccbc7a548f7872105b145b8eea4b76b175`, arm `error:SyntaxError`
- `J1R:120` - input `(3180 characters)`: S `len:5242:sha256:fa64b1cf2c3d0b6e509e57c2150f6caf9983e0c395529468b13da461fd2c0c94`, arm `error:SyntaxError`
- `J1R:132` - input `(3046 characters)`: S `len:4898:sha256:0329382293c73768b97d73a1d84edfdadb48013e309844848e6d7dc0903d8352`, arm `error:SyntaxError`
- `J1R:160` - input `(3335 characters)`: S `len:5319:sha256:e37f326184408a74034987b8b98b44972dd7af7b6fdef8bdedfdb30c81722545`, arm `error:SyntaxError`
- `J1R:161` - input `(3334 characters)`: S `len:5318:sha256:e5f8994ec382d08a12ed03a698d2c3f105b6321dd24632afa9bd147702f3e040`, arm `error:SyntaxError`
- `J1R:164` - input `(3564 characters)`: S `len:5717:sha256:90afb1160d73128670818c85e013c88409f9f0e2428f1e4821bd0b9fe54993c4`, arm `error:SyntaxError`
- `J1R:165` - input `(3565 characters)`: S `len:5718:sha256:1f9ff6c9070d76d76334fb291e7d60ac58dfa09747523071c88f1d386fc173c0`, arm `error:SyntaxError`
- `J1R:166` - input `(3499 characters)`: S `len:5435:sha256:a23928850273cb1ea5b3de4bc185e9abeeb3fc12278d8ec7906bee6976feb6de`, arm `error:SyntaxError`
- `J1R:176` - input `(2806 characters)`: S `len:4631:sha256:a6e30bde7c7e83c4a6cd5b59bebd94d2c40d5dbeb540f32a64c4719200e7b6d4`, arm `error:SyntaxError`
- `J1R:186` - input `(3352 characters)`: S `len:5376:sha256:c00052b45e31d1d641c188399e7d05a0502696dd8291046a48a38738c596816a`, arm `error:SyntaxError`
- `J1R:202` - input `(4073 characters)`: S `len:6705:sha256:0c22fe36f80abda5a13475f5f360d471d4a26adc316ea6bc9dd07d4ad4835096`, arm `error:SyntaxError`
- `J1R:230` - input `(3168 characters)`: S `len:5100:sha256:f9e1e84aab6bd98b88eee4de866a54eddb46a073944d87ecb37f203406a68105`, arm `error:SyntaxError`

## JSON parse, J:JSJSON.Parse: unclassified, 13227

the input was shortened in the listing.

- `J1R:0` - input `len:10348:sha256:a3e59344713a0d04d7cc5951e6dd107bbc6d0fb37e90d13ff8984f5797be3a46`: S `len:16751:sha256:402bff44f5eef0833827e953b70410236b348fa0e08232cca3e0f5c03a48895d`, arm `error:SyntaxError`
- `J1R:2` - input `len:9038:sha256:3ebb5d9bcf03d263188693115c93c2250ff7031326279535bd58ac025468f964`: S `len:14767:sha256:858ddd2eefb6d6962d163b047321cd4b9142453cccdf9c36ed9bfbabdb5757c7`, arm `error:SyntaxError`
- `J1R:6` - input `len:4903:sha256:0b0b0ff8248cb01abcaaac7124ebc45221f0164bd2d15c101352fac03d405441`: S `len:7952:sha256:6cfed3cd3aa0297a3c5857166163d40c2580af4dad8ba7697bf7495b83e0274e`, arm `error:SyntaxError`
- `J1R:7` - input `len:4903:sha256:a6960ca4b2bafc8e029e2c7bbde1419b2ac80c8dc510ccdd961b24743a59bc22`: S `len:7952:sha256:1950a622af8e1118155696ed3ab63681f0a57ad82afe1e768790598fb6718c53`, arm `error:SyntaxError`
- `J1R:8` - input `len:4354:sha256:2a38a4a69200083726999f89a22ba384e51a8abcf22df42d95ffda4204990a5f`: S `len:7071:sha256:1a4d6c539916c6763599970ac454c5b0031976d572c450b157799904b855e478`, arm `error:SyntaxError`
- `J1R:10` - input `len:8284:sha256:9dfc513503e7e3dc480de4d638f2e92f7f9259c6df9a6a64fbc019bf10bb6d9c`: S `len:13146:sha256:83d75851caf32424d5d28fa84cee8045601d18ddacf3bf53ac163d3fce21a85b`, arm `error:SyntaxError`
- `J1R:12` - input `len:8989:sha256:49e64953a9c6bc12df9abd4bb4d33d417920a63836e6c881b152851f82cfdc15`: S `len:14172:sha256:115dcb74b3e5023a43b5270421173fc9891b44162519e3172d6674f60f1f322b`, arm `error:SyntaxError`
- `J1R:13` - input `len:8988:sha256:b1c13cd8c851415fbcd2867c43f744980a8eba07875d7f7e255ecf1def28e54a`: S `len:14172:sha256:93d21cdf2c77f647c05bea9cdf5ed124f01bb0a3c5e2559752fda6ac688e84cd`, arm `error:SyntaxError`
- `J1R:14` - input `len:9313:sha256:782926e664c9d1ca73777a94ee09e6c280a468c49f47089a0d34edfb6d5ac92d`: S `len:15345:sha256:c921e782f10b9e800a3caa14bc3751bd1a7a451888e98b54ce3fe156d01a3dea`, arm `error:SyntaxError`
- `J1R:15` - input `len:9313:sha256:d8e0795fd00243e674b77677886c9b05e64336a855ee544af2cec08857746398`: S `len:15345:sha256:325919f97d4d62344df9dbb2495d17409982f1d0f60c3b390f3d7869bde13bc6`, arm `error:SyntaxError`
- `J1R:22` - input `len:7616:sha256:f4fc18206df3ec77f8ba9d97dc851fc285a649649d159cdc0b5f705f6dc5f436`: S `len:11917:sha256:0cbbf5d8d757d1b26e6056a4860bfb82e441b481c5eed3e1babe5b38ab2b546d`, arm `error:SyntaxError`
- `J1R:23` - input `len:7616:sha256:f4fc18206df3ec77f8ba9d97dc851fc285a649649d159cdc0b5f705f6dc5f436`: S `len:11917:sha256:0cbbf5d8d757d1b26e6056a4860bfb82e441b481c5eed3e1babe5b38ab2b546d`, arm `error:SyntaxError`
- `J1R:24` - input `len:4563:sha256:56e205c725027808f5e7d5a956f55c7267e65084cd36323b4950f3f0ee0af412`: S `len:7381:sha256:2f03caae7050c6c787c7b0dfdbbb0a28e7c8a046521b95dbb1cebad1fe1a817d`, arm `error:SyntaxError`
- `J1R:28` - input `len:10162:sha256:c7d25d7dec79703315f9929554203b8f64bcd941da2ffd8a6f20127b6158b8ef`: S `len:15920:sha256:5be734df8d75d3d93018701a391a000d9b0ac75f3c62913ca4a65fe068258c40`, arm `error:SyntaxError`
- `J1R:29` - input `len:10161:sha256:0d12b45ec67ed2ac534cc0011b5518c2c0e63eeb9d179e903b75547fd52c72ba`: S `len:15919:sha256:61ab9e8ed3db724b6faf07ec05669900adfd3df61d5066c168cdab987a85eb90`, arm `error:SyntaxError`
- `J1R:34` - input `len:9597:sha256:2b3c64e5871e28b66f06e9a9e7da9b573d0453418aaf595deb6d0352ee1c9708`: S `len:15740:sha256:4a128c353b1c33aa2591f6dcb974000531e298df9894509f087335c93398bbba`, arm `error:SyntaxError`
- `J1R:35` - input `len:9598:sha256:9dad88e3a831893899227bfedceca7c86a1638582e4e609017335ee60736281c`: S `len:15741:sha256:89c7de554ae6cf95097d5bea1bc2e8bfa9730df07389eab87a417fca169f5ce2`, arm `error:SyntaxError`
- `J1R:42` - input `len:7579:sha256:6298fe294ee20efba0558d2e21a2f86db66db3e73c4339656ebd2962f45a7e7d`: S `len:12207:sha256:4eeb75c768baf5c400cc732652f4ba87847a7028f31b987ea337f38d05fa9f17`, arm `error:SyntaxError`
- `J1R:50` - input `len:4806:sha256:7650a919c4d280c1201fa5d5458c5560431d77391e0aa355bbae77576123cc93`: S `len:7624:sha256:f073fe4fc3230b148f5c6b1c2d29aeca2add4db35191e8171603dc8583e3c7e5`, arm `error:SyntaxError`
- `J1R:52` - input `len:7822:sha256:fe10efa101922ab252435beda2aa5cd482ab266fb89f858f24b5409e296b8c13`: S `len:12720:sha256:b1aae62fedec33494ab705874252f4c03bffc74ceeb034cc8cf3096be0b97551`, arm `error:SyntaxError`

## StringPad, V:StringPadTo: (a), 84

correction of Broiler.VM: S is the reference's; P2.

- `P1S:0` 16777217/filler0/start input ``: S `str:|charge:1`, arm `error:RangeError|charge:0`
- `P1S:0` 16777217/filler0/end input ``: S `str:|charge:1`, arm `error:RangeError|charge:0`
- `P1S:0` 1073741823/filler0/start input ``: S `str:|charge:1`, arm `error:RangeError|charge:0`
- `P1S:0` 1073741823/filler0/end input ``: S `str:|charge:1`, arm `error:RangeError|charge:0`
- `P1S:0` 1073741824/filler0/start input ``: S `str:|charge:1`, arm `error:RangeError|charge:0`
- `P1S:0` 1073741824/filler0/end input ``: S `str:|charge:1`, arm `error:RangeError|charge:0`
- `P1S:0` 1073741825/filler0/start input ``: S `str:|charge:1`, arm `error:RangeError|charge:0`
- `P1S:0` 1073741825/filler0/end input ``: S `str:|charge:1`, arm `error:RangeError|charge:0`
- `P1S:0` 2147483646/filler0/start input ``: S `str:|charge:1`, arm `error:RangeError|charge:0`
- `P1S:0` 2147483646/filler0/end input ``: S `str:|charge:1`, arm `error:RangeError|charge:0`
- `P1S:0` 2147483647/filler0/start input ``: S `str:|charge:1`, arm `error:RangeError|charge:0`
- `P1S:0` 2147483647/filler0/end input ``: S `str:|charge:1`, arm `error:RangeError|charge:0`
- `P1S:0` 2147483648/filler0/start input ``: S `str:|charge:1`, arm `error:RangeError|charge:0`
- `P1S:0` 2147483648/filler0/end input ``: S `str:|charge:1`, arm `error:RangeError|charge:0`
- `P1S:1` 16777217/filler0/start input `a`: S `str:a|charge:1`, arm `error:RangeError|charge:0`
- `P1S:1` 16777217/filler0/end input `a`: S `str:a|charge:1`, arm `error:RangeError|charge:0`
- `P1S:1` 1073741823/filler0/start input `a`: S `str:a|charge:1`, arm `error:RangeError|charge:0`
- `P1S:1` 1073741823/filler0/end input `a`: S `str:a|charge:1`, arm `error:RangeError|charge:0`
- `P1S:1` 1073741824/filler0/start input `a`: S `str:a|charge:1`, arm `error:RangeError|charge:0`
- `P1S:1` 1073741824/filler0/end input `a`: S `str:a|charge:1`, arm `error:RangeError|charge:0`
