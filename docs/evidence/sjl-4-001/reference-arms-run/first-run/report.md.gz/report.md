# Reference-arm comparison of the numerics area: classification

Differences listed: 8067692; classified: 8067692; unclassified: 1062.

## A rational's nearest double / J:JSTemporalDuration.RatioToDouble / class a / does not round the rational once to the nearest double: 31636

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| R1D:2 | - | (472 characters) | f64:8000000000000000 | f64:0000000000000000 | f64:8000000000000000 |  |
| R1D:3 | - | (731 characters) | f64:8000000000000000 | f64:0000000000000000 | f64:8000000000000000 |  |
| R1D:6 | - | -5dbacc514c552930aafef3c94dcda8cb4f55ecc9b4354bd6caf87c 112760c5c85517fc4a40049cbcf087200276688ea0a7ff0046cbcb614bd909ff | f64:9DD5DB353D4CC61F | f64:0000000000000000 | f64:9DD5DB353D4CC61F |  |
| R1D:10 | - | (450 characters) | f64:8000000000000000 | f64:0000000000000000 | f64:8000000000000000 |  |
| R1D:11 | - | (376 characters) | f64:970A97CB95C3FE33 | f64:0000000000000000 | f64:970A97CB95C3FE33 |  |
| R1D:12 | - | (811 characters) | f64:F3C57CC703E42AEA | f64:FFF0000000000000 | f64:F3C57CC703E42AEA |  |
| R1D:20 | - | (702 characters) | f64:A496B6B8E20D46B1 | f64:0000000000000000 | f64:A496B6B8E20D46B1 |  |
| R1D:23 | - | cc9c98be9eb9bc8323 7cd532aff066490a98fcd56a4c5a9f5da7d23b217ce8fc48f7a23ab5d9ee97e08bca2f5812d2f523ea39b02f729d859888019 | f64:09BA39B244BD9AD3 | f64:0000000000000000 | f64:09BA39B244BD9AD3 |  |
| R1D:27 | - | (458 characters) | f64:8000000000000000 | f64:0000000000000000 | f64:8000000000000000 |  |
| R1D:30 | - | f71bba4090efe922a70dde2d5200d492 37796ae2e1121ad365566bbd5e31bb42c6e00bf1aa94fc7f515aaec70b3035fd7970368e1376d7b34edd9fe | f64:1951D15F763E1FFB | f64:0000000000000000 | f64:1951D15F763E1FFB |  |
| R1D:32 | - | (723 characters) | f64:1E738331A66179E8 | f64:0000000000000000 | f64:1E738331A66179E8 |  |
| R1D:33 | - | (868 characters) | f64:2921CF9833E6857C | f64:0000000000000000 | f64:2921CF9833E6857C |  |
| R1D:35 | - | (591 characters) | f64:F28A4C2F8EE5ED4B | f64:FFF0000000000000 | f64:F28A4C2F8EE5ED4B |  |
| R1D:36 | - | (658 characters) | f64:02164A67556C407D | f64:0000000000000000 | f64:02164A67556C407D |  |
| R1D:40 | - | (382 characters) | f64:8000000000000000 | f64:0000000000000000 | f64:8000000000000000 |  |
| R1D:41 | - | (624 characters) | f64:31149F3D8B18F0EF | f64:31149F3C00000000 | f64:31149F3D8B18F0EF |  |
| R1D:43 | - | (975 characters) | f64:88504C107C0A9FFE | f64:0000000000000000 | f64:88504C107C0A9FFE |  |
| R1D:44 | - | (354 characters) | f64:8000000000000000 | f64:0000000000000000 | f64:8000000000000000 |  |
| R1D:45 | - | (379 characters) | f64:7CF5822E15601F19 | f64:7FF0000000000000 | f64:7CF5822E15601F19 |  |
| R1D:48 | - | (806 characters) | f64:13AE6BAA64CCDEFC | f64:0000000000000000 | f64:13AE6BAA64CCDEFC |  |

## A rational's nearest double / V:JsTemporalCore.ToDouble(num, den) / class a / does not round the rational once to the nearest double: 143

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| R1D:5011 | - | (395 characters) | f64:0001C6B9D5313AB5 | f64:0001C6B9D5313AB4 | f64:0001C6B9D5313AB5 |  |
| R1D:5167 | - | (572 characters) | f64:80080C5F0A9BF217 | f64:80080C5F0A9BF218 | f64:80080C5F0A9BF217 |  |
| R1D:5605 | - | (483 characters) | f64:80080B16DF347D75 | f64:80080B16DF347D74 | f64:80080B16DF347D75 |  |
| R1D:37661 | - | (364 characters) | f64:800797677F87E9F7 | f64:800797677F87E9F6 | f64:800797677F87E9F7 |  |
| R1D:38889 | - | (453 characters) | f64:800F1B05CF92F24F | f64:800F1B05CF92F24E | f64:800F1B05CF92F24F |  |
| R1D:42734 | - | (944 characters) | f64:000A8F193188550D | f64:000A8F193188550E | f64:000A8F193188550D |  |
| R1D:51912 | - | (396 characters) | f64:800DC1FF381CEB71 | f64:800DC1FF381CEB72 | f64:800DC1FF381CEB71 |  |
| R1D:53461 | - | (272 characters) | f64:8004817F40EA33A3 | f64:8004817F40EA33A2 | f64:8004817F40EA33A3 |  |
| R1D:57347 | - | (542 characters) | f64:80098ECE88F50A3B | f64:80098ECE88F50A3C | f64:80098ECE88F50A3B |  |
| R1D:65540 | - | (808 characters) | f64:0000000000000001 | f64:0000000000000000 | f64:0000000000000001 |  |
| R1D:65541 | - | (809 characters) | f64:8000000000000001 | f64:8000000000000000 | f64:8000000000000001 |  |
| R1D:65542 | - | (809 characters) | f64:0000000000000001 | f64:0000000000000002 | f64:0000000000000001 |  |
| R1D:65543 | - | (810 characters) | f64:8000000000000001 | f64:8000000000000002 | f64:8000000000000001 |  |
| R1D:65552 | - | (809 characters) | f64:0000000000000003 | f64:0000000000000002 | f64:0000000000000003 |  |
| R1D:65553 | - | (810 characters) | f64:8000000000000003 | f64:8000000000000002 | f64:8000000000000003 |  |
| R1D:65554 | - | (809 characters) | f64:0000000000000003 | f64:0000000000000004 | f64:0000000000000003 |  |
| R1D:65555 | - | (810 characters) | f64:8000000000000003 | f64:8000000000000004 | f64:8000000000000003 |  |
| R1D:65564 | - | (809 characters) | f64:0000000000000005 | f64:0000000000000004 | f64:0000000000000005 |  |
| R1D:65565 | - | (810 characters) | f64:8000000000000005 | f64:8000000000000004 | f64:8000000000000005 |  |
| R1D:65566 | - | (809 characters) | f64:0000000000000005 | f64:0000000000000006 | f64:0000000000000005 |  |

## An integer's nearest double / J:JSTemporalDuration.NearestDouble / class a / answers another value: 6

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| B1E:18457 | - | fffffffffffffc0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 | f64:7FF0000000000000 | f64:7FEFFFFFFFFFFFFF | f64:7FF0000000000000 |  |
| B1E:18458 | - | fffffffffffffc0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 | f64:7FF0000000000000 | f64:7FEFFFFFFFFFFFFF | f64:7FF0000000000000 |  |
| B1E:18459 | - | ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff | f64:7FF0000000000000 | f64:7FEFFFFFFFFFFFFF | f64:7FF0000000000000 |  |
| B1E:18460 | - | (257 characters) | f64:FFF0000000000000 | f64:FFEFFFFFFFFFFFFF | f64:FFF0000000000000 |  |
| B1E:18461 | - | ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff | f64:7FF0000000000000 | f64:7FEFFFFFFFFFFFFF | f64:7FF0000000000000 |  |
| B1E:18462 | - | (257 characters) | f64:FFF0000000000000 | f64:FFEFFFFFFFFFFFFF | f64:FFF0000000000000 |  |

## ApplyUnsignedRoundingMode, a window / J:JSTemporalPlainDate's NudgeToCalendarUnit with TemporalRoundingOptions.ApplyRoundingPicksEnd / class a / rounds to the other end: 1104

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| R1W:328 | ceil/negative | c 6 0 2 | False | True | False |  |
| R1W:328 | floor/positive | c 6 0 2 | False | True | False |  |
| R1W:328 | trunc/positive | c 6 0 2 | False | True | False |  |
| R1W:328 | trunc/negative | c 6 0 2 | False | True | False |  |
| R1W:335 | ceil/negative | 40000000000000000 20000000000000000 0 2 | False | True | False |  |
| R1W:335 | floor/positive | 40000000000000000 20000000000000000 0 2 | False | True | False |  |
| R1W:335 | trunc/positive | 40000000000000000 20000000000000000 0 2 | False | True | False |  |
| R1W:335 | trunc/negative | 40000000000000000 20000000000000000 0 2 | False | True | False |  |
| R1W:342 | ceil/negative | 18 6 2 4 | False | True | False |  |
| R1W:342 | floor/positive | 18 6 2 4 | False | True | False |  |
| R1W:342 | trunc/positive | 18 6 2 4 | False | True | False |  |
| R1W:342 | trunc/negative | 18 6 2 4 | False | True | False |  |
| R1W:349 | ceil/negative | 80000000000000000 20000000000000000 2 4 | False | True | False |  |
| R1W:349 | floor/positive | 80000000000000000 20000000000000000 2 4 | False | True | False |  |
| R1W:349 | trunc/positive | 80000000000000000 20000000000000000 2 4 | False | True | False |  |
| R1W:349 | trunc/negative | 80000000000000000 20000000000000000 2 4 | False | True | False |  |
| R1W:356 | ceil/negative | 24 6 4 6 | False | True | False |  |
| R1W:356 | floor/positive | 24 6 4 6 | False | True | False |  |
| R1W:356 | trunc/positive | 24 6 4 6 | False | True | False |  |
| R1W:356 | trunc/negative | 24 6 4 6 | False | True | False |  |

## ApplyUnsignedRoundingMode, a window / J:JSTemporalZonedDateTime's NudgeToCalendarUnit with ApplyRoundingPicksEnd / class a / rounds to the other end: 1104

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| R1W:328 | ceil/negative | c 6 0 2 | False | True | False |  |
| R1W:328 | floor/positive | c 6 0 2 | False | True | False |  |
| R1W:328 | trunc/positive | c 6 0 2 | False | True | False |  |
| R1W:328 | trunc/negative | c 6 0 2 | False | True | False |  |
| R1W:335 | ceil/negative | 40000000000000000 20000000000000000 0 2 | False | True | False |  |
| R1W:335 | floor/positive | 40000000000000000 20000000000000000 0 2 | False | True | False |  |
| R1W:335 | trunc/positive | 40000000000000000 20000000000000000 0 2 | False | True | False |  |
| R1W:335 | trunc/negative | 40000000000000000 20000000000000000 0 2 | False | True | False |  |
| R1W:342 | ceil/negative | 18 6 2 4 | False | True | False |  |
| R1W:342 | floor/positive | 18 6 2 4 | False | True | False |  |
| R1W:342 | trunc/positive | 18 6 2 4 | False | True | False |  |
| R1W:342 | trunc/negative | 18 6 2 4 | False | True | False |  |
| R1W:349 | ceil/negative | 80000000000000000 20000000000000000 2 4 | False | True | False |  |
| R1W:349 | floor/positive | 80000000000000000 20000000000000000 2 4 | False | True | False |  |
| R1W:349 | trunc/positive | 80000000000000000 20000000000000000 2 4 | False | True | False |  |
| R1W:349 | trunc/negative | 80000000000000000 20000000000000000 2 4 | False | True | False |  |
| R1W:356 | ceil/negative | 24 6 4 6 | False | True | False |  |
| R1W:356 | floor/positive | 24 6 4 6 | False | True | False |  |
| R1W:356 | trunc/positive | 24 6 4 6 | False | True | False |  |
| R1W:356 | trunc/negative | 24 6 4 6 | False | True | False |  |

## BigInt.asUintN / J:JSBigInt.AsUintN / class a / answers an input the clause or the policy refuses: 28664

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| B1N:32 | - | 2 100000000 | error:RangeError | bigint:0 | error:RangeError |  |
| B1N:33 | - | 2 100000003 | error:RangeError | bigint:7 | error:RangeError |  |
| B1N:58 | - | 4 100000000 | error:RangeError | bigint:0 | error:RangeError |  |
| B1N:59 | - | 4 100000003 | error:RangeError | bigint:6 | error:RangeError |  |
| B1N:84 | - | 6 100000000 | error:RangeError | bigint:0 | error:RangeError |  |
| B1N:85 | - | 6 100000003 | error:RangeError | bigint:5 | error:RangeError |  |
| B1N:108 | - | 8 100000000 | error:RangeError | bigint:0 | error:RangeError |  |
| B1N:109 | - | 8 100000003 | error:RangeError | bigint:7 | error:RangeError |  |
| B1N:136 | - | 10 100000000 | error:RangeError | bigint:0 | error:RangeError |  |
| B1N:137 | - | 10 100000003 | error:RangeError | bigint:4 | error:RangeError |  |
| B1N:164 | - | 12 100000000 | error:RangeError | bigint:0 | error:RangeError |  |
| B1N:165 | - | 12 100000003 | error:RangeError | bigint:3 | error:RangeError |  |
| B1N:190 | - | 14 100000000 | error:RangeError | bigint:0 | error:RangeError |  |
| B1N:191 | - | 14 100000003 | error:RangeError | bigint:5 | error:RangeError |  |
| B1N:218 | - | 16 100000000 | error:RangeError | bigint:0 | error:RangeError |  |
| B1N:219 | - | 16 100000003 | error:RangeError | bigint:0 | error:RangeError |  |
| B1N:246 | - | 18 100000000 | error:RangeError | bigint:0 | error:RangeError |  |
| B1N:247 | - | 18 100000003 | error:RangeError | bigint:7 | error:RangeError |  |
| B1N:274 | - | 20 100000000 | error:RangeError | bigint:0 | error:RangeError |  |
| B1N:275 | - | 20 100000003 | error:RangeError | bigint:1 | error:RangeError |  |

## BigInt.asUintN / J:JSBigInt.AsUintN / class a / throws DivideByZeroException where the clause gives a result or a RangeError: 28664

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| B1N:31 | - | 2 80000000 | error:RangeError | exception:DivideByZeroException | error:RangeError |  |
| B1N:34 | - | 2 1fffffffffffff | error:RangeError | exception:DivideByZeroException | error:RangeError |  |
| B1N:57 | - | 4 80000000 | error:RangeError | exception:DivideByZeroException | error:RangeError |  |
| B1N:60 | - | 4 1fffffffffffff | error:RangeError | exception:DivideByZeroException | error:RangeError |  |
| B1N:83 | - | 6 80000000 | error:RangeError | exception:DivideByZeroException | error:RangeError |  |
| B1N:86 | - | 6 1fffffffffffff | error:RangeError | exception:DivideByZeroException | error:RangeError |  |
| B1N:107 | - | 8 80000000 | error:RangeError | exception:DivideByZeroException | error:RangeError |  |
| B1N:110 | - | 8 1fffffffffffff | error:RangeError | exception:DivideByZeroException | error:RangeError |  |
| B1N:135 | - | 10 80000000 | error:RangeError | exception:DivideByZeroException | error:RangeError |  |
| B1N:138 | - | 10 1fffffffffffff | error:RangeError | exception:DivideByZeroException | error:RangeError |  |
| B1N:163 | - | 12 80000000 | error:RangeError | exception:DivideByZeroException | error:RangeError |  |
| B1N:166 | - | 12 1fffffffffffff | error:RangeError | exception:DivideByZeroException | error:RangeError |  |
| B1N:189 | - | 14 80000000 | error:RangeError | exception:DivideByZeroException | error:RangeError |  |
| B1N:192 | - | 14 1fffffffffffff | error:RangeError | exception:DivideByZeroException | error:RangeError |  |
| B1N:217 | - | 16 80000000 | error:RangeError | exception:DivideByZeroException | error:RangeError |  |
| B1N:220 | - | 16 1fffffffffffff | error:RangeError | exception:DivideByZeroException | error:RangeError |  |
| B1N:245 | - | 18 80000000 | error:RangeError | exception:DivideByZeroException | error:RangeError |  |
| B1N:248 | - | 18 1fffffffffffff | error:RangeError | exception:DivideByZeroException | error:RangeError |  |
| B1N:273 | - | 20 80000000 | error:RangeError | exception:DivideByZeroException | error:RangeError |  |
| B1N:276 | - | 20 1fffffffffffff | error:RangeError | exception:DivideByZeroException | error:RangeError |  |

## BigInt::exponentiate / J:JSBigInt.Power / class a / throws OverflowException where the clause gives a result or a RangeError: 8473

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| B1P:0 | - | 19661 24127 | error:RangeError | exception:OverflowException | error:RangeError |  |
| B1P:2 | - | 4294 11947 | error:RangeError | exception:OverflowException | error:RangeError |  |
| B1P:3 | - | 13348 12765 | error:RangeError | exception:OverflowException | error:RangeError |  |
| B1P:4 | - | 9741 15399 | error:RangeError | exception:OverflowException | error:RangeError |  |
| B1P:6 | - | 4013 24773 | error:RangeError | exception:OverflowException | error:RangeError |  |
| B1P:10 | - | 23499 4099 | error:RangeError | exception:OverflowException | error:RangeError |  |
| B1P:11 | - | 7507 2221 | error:RangeError | exception:OverflowException | error:RangeError |  |
| B1P:13 | - | 20798 12629 | error:RangeError | exception:OverflowException | error:RangeError |  |
| B1P:14 | - | 21234 4973 | error:RangeError | exception:OverflowException | error:RangeError |  |
| B1P:17 | - | 24090 21053 | error:RangeError | exception:OverflowException | error:RangeError |  |
| B1P:19 | - | 3102 3751 | error:RangeError | exception:OverflowException | error:RangeError |  |
| B1P:20 | - | 25450 19033 | error:RangeError | exception:OverflowException | error:RangeError |  |
| B1P:25 | - | 25426 4983 | error:RangeError | exception:OverflowException | error:RangeError |  |
| B1P:26 | - | 13644 21637 | error:RangeError | exception:OverflowException | error:RangeError |  |
| B1P:28 | - | 23496 12431 | error:RangeError | exception:OverflowException | error:RangeError |  |
| B1P:32 | - | 15700 20843 | error:RangeError | exception:OverflowException | error:RangeError |  |
| B1P:33 | - | 25637 781 | error:RangeError | exception:OverflowException | error:RangeError |  |
| B1P:35 | - | 3930 4881 | error:RangeError | exception:OverflowException | error:RangeError |  |
| B1P:36 | - | 15362 4541 | error:RangeError | exception:OverflowException | error:RangeError |  |
| B1P:38 | - | 11122 1375 | error:RangeError | exception:OverflowException | error:RangeError |  |

## BigInt::toString / J:JSBigInt.BigIntegerToRadixString (radix 10: ToString), under U+2212 / class a / follows the process's culture (its negative sign): 14332

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| B1V:2 | 10 | -1 | -1 | \u22121 | -1 |  |
| B1V:4 | 10 | -2 | -2 | \u22122 | -2 |  |
| B1V:6 | 10 | -3 | -3 | \u22123 | -3 |  |
| B1V:8 | 10 | -1 | -1 | \u22121 | -1 |  |
| B1V:10 | 10 | -4 | -4 | \u22124 | -4 |  |
| B1V:12 | 10 | -5 | -5 | \u22125 | -5 |  |
| B1V:14 | 10 | -3 | -3 | \u22123 | -3 |  |
| B1V:16 | 10 | -8 | -8 | \u22128 | -8 |  |
| B1V:18 | 10 | -9 | -9 | \u22129 | -9 |  |
| B1V:20 | 10 | -7 | -7 | \u22127 | -7 |  |
| B1V:22 | 10 | -10 | -16 | \u221216 | -16 |  |
| B1V:24 | 10 | -11 | -17 | \u221217 | -17 |  |
| B1V:26 | 10 | -f | -15 | \u221215 | -15 |  |
| B1V:28 | 10 | -20 | -32 | \u221232 | -32 |  |
| B1V:30 | 10 | -21 | -33 | \u221233 | -33 |  |
| B1V:32 | 10 | -1f | -31 | \u221231 | -31 |  |
| B1V:34 | 10 | -40 | -64 | \u221264 | -64 |  |
| B1V:36 | 10 | -41 | -65 | \u221265 | -65 |  |
| B1V:38 | 10 | -3f | -63 | \u221263 | -63 |  |
| B1V:40 | 10 | -80 | -128 | \u2212128 | -128 |  |

## Comparison with a Number / J:JSBigInt.EqualsLiteral / class a / orders the BigInt and the Number wrongly: 2

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| B1V:6145 | B1C:8 | ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff | False | True | False |  |
| B1V:6146 | B1C:9 | (257 characters) | False | True | False |  |

## Math.cbrt / J:JSMath.Cbrt / class b / both admitted: 145011

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:2 | - | 0000000000000001 | f64:2990000000000000 | f64:298FFFFFFFFFFFFF | f64:2990000000000000 (faithful f64:2990000000000000) | numerics/cbrt/0006 (revision 6) |
| N1:3 | - | 8000000000000001 | f64:A990000000000000 | f64:A98FFFFFFFFFFFFF | f64:A990000000000000 (faithful f64:A990000000000000) | numerics/cbrt/0006 (revision 6) |
| N1:4 | - | 000FFFFFFFFFFFFF | f64:2AA428A2F98D728A | f64:2AA428A2F98D728B | f64:2AA428A2F98D728A (faithful f64:2AA428A2F98D728A, f64:2AA428A2F98D728B) | numerics/cbrt/0006 (revision 6) |
| N1:5 | - | 800FFFFFFFFFFFFF | f64:AAA428A2F98D728A | f64:AAA428A2F98D728B | f64:AAA428A2F98D728A (faithful f64:AAA428A2F98D728A, f64:AAA428A2F98D728B) | numerics/cbrt/0006 (revision 6) |
| N1:8 | - | 7FEFFFFFFFFFFFFF | f64:554428A2F98D728B | f64:554428A2F98D728A | f64:554428A2F98D728B (faithful f64:554428A2F98D728A, f64:554428A2F98D728B) | numerics/cbrt/0006 (revision 6) |
| N1:9 | - | FFEFFFFFFFFFFFFF | f64:D54428A2F98D728B | f64:D54428A2F98D728A | f64:D54428A2F98D728B (faithful f64:D54428A2F98D728A, f64:D54428A2F98D728B) | numerics/cbrt/0006 (revision 6) |
| N1:14 | - | 0000000000000003 | f64:2997137449123EF6 | f64:2997137449123EF5 | f64:2997137449123EF6 (faithful f64:2997137449123EF6, f64:2997137449123EF7) | numerics/cbrt/0006 (revision 6) |
| N1:16 | - | 0000000000000005 | f64:299B5C0FBCFEC4D4 | f64:299B5C0FBCFEC4D3 | f64:299B5C0FBCFEC4D4 (faithful f64:299B5C0FBCFEC4D3, f64:299B5C0FBCFEC4D4) | numerics/cbrt/0006 (revision 6) |
| N1:17 | - | 0000000000000007 | f64:299E9B5DBA58189E | f64:299E9B5DBA58189F | f64:299E9B5DBA58189E (faithful f64:299E9B5DBA58189D, f64:299E9B5DBA58189E) | numerics/cbrt/0006 (revision 6) |
| N1:18 | - | 0000000000000008 | f64:29A0000000000000 | f64:299FFFFFFFFFFFFF | f64:29A0000000000000 (faithful f64:29A0000000000000) | numerics/cbrt/0006 (revision 6) |
| N1:19 | - | 0000000000000009 | f64:29A0A402FCC79298 | f64:29A0A402FCC79297 | f64:29A0A402FCC79298 (faithful f64:29A0A402FCC79298, f64:29A0A402FCC79299) | numerics/cbrt/0006 (revision 6) |
| N1:20 | - | 000000000000000F | f64:29A3BACD6561FF5E | f64:29A3BACD6561FF5C | f64:29A3BACD6561FF5E (faithful f64:29A3BACD6561FF5D, f64:29A3BACD6561FF5E) | numerics/cbrt/0006 (revision 6) |
| N1:23 | - | 000000000000001F | f64:29A9218C2DF27726 | f64:29A9218C2DF27725 | f64:29A9218C2DF27726 (faithful f64:29A9218C2DF27725, f64:29A9218C2DF27726) | numerics/cbrt/0006 (revision 6) |
| N1:25 | - | 0000000000000021 | f64:29A9A907C24108E7 | f64:29A9A907C24108E8 | f64:29A9A907C24108E7 (faithful f64:29A9A907C24108E6, f64:29A9A907C24108E7) | numerics/cbrt/0006 (revision 6) |
| N1:26 | - | 000000000000003F | f64:29AFD51BF2069FE6 | f64:29AFD51BF2069FE7 | f64:29AFD51BF2069FE6 (faithful f64:29AFD51BF2069FE6, f64:29AFD51BF2069FE7) | numerics/cbrt/0006 (revision 6) |
| N1:27 | - | 0000000000000040 | f64:29B0000000000000 | f64:29AFFFFFFFFFFFFF | f64:29B0000000000000 (faithful f64:29B0000000000000) | numerics/cbrt/0006 (revision 6) |
| N1:28 | - | 0000000000000041 | f64:29B01539221D4C97 | f64:29B01539221D4C96 | f64:29B01539221D4C97 (faithful f64:29B01539221D4C97, f64:29B01539221D4C98) | numerics/cbrt/0006 (revision 6) |
| N1:29 | - | 000000000000007F | f64:29B41B298D47800E | f64:29B41B298D47800D | f64:29B41B298D47800E (faithful f64:29B41B298D47800E, f64:29B41B298D47800F) | numerics/cbrt/0006 (revision 6) |
| N1:31 | - | 0000000000000081 | f64:29B4360A7A7D5067 | f64:29B4360A7A7D5066 | f64:29B4360A7A7D5067 (faithful f64:29B4360A7A7D5067, f64:29B4360A7A7D5068) | numerics/cbrt/0006 (revision 6) |
| N1:36 | - | 0000000000000200 | f64:29C0000000000000 | f64:29BFFFFFFFFFFFFF | f64:29C0000000000000 (faithful f64:29C0000000000000) | numerics/cbrt/0006 (revision 6) |

## Math.cbrt / V:JsRealm's cbrt / class b / both admitted: 576644

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:2 | - | 0000000000000001 | f64:2990000000000000 | f64:298FFFFFFFFFFFFF | f64:2990000000000000 (faithful f64:2990000000000000) | numerics/cbrt/0006 (revision 6) |
| N1:3 | - | 8000000000000001 | f64:A990000000000000 | f64:A98FFFFFFFFFFFFF | f64:A990000000000000 (faithful f64:A990000000000000) | numerics/cbrt/0006 (revision 6) |
| N1:4 | - | 000FFFFFFFFFFFFF | f64:2AA428A2F98D728A | f64:2AA428A2F98D728B | f64:2AA428A2F98D728A (faithful f64:2AA428A2F98D728A, f64:2AA428A2F98D728B) | numerics/cbrt/0006 (revision 6) |
| N1:5 | - | 800FFFFFFFFFFFFF | f64:AAA428A2F98D728A | f64:AAA428A2F98D728B | f64:AAA428A2F98D728A (faithful f64:AAA428A2F98D728A, f64:AAA428A2F98D728B) | numerics/cbrt/0006 (revision 6) |
| N1:14 | - | 0000000000000003 | f64:2997137449123EF6 | f64:2997137449123EF5 | f64:2997137449123EF6 (faithful f64:2997137449123EF6, f64:2997137449123EF7) | numerics/cbrt/0006 (revision 6) |
| N1:16 | - | 0000000000000005 | f64:299B5C0FBCFEC4D4 | f64:299B5C0FBCFEC4D3 | f64:299B5C0FBCFEC4D4 (faithful f64:299B5C0FBCFEC4D3, f64:299B5C0FBCFEC4D4) | numerics/cbrt/0006 (revision 6) |
| N1:17 | - | 0000000000000007 | f64:299E9B5DBA58189E | f64:299E9B5DBA58189F | f64:299E9B5DBA58189E (faithful f64:299E9B5DBA58189D, f64:299E9B5DBA58189E) | numerics/cbrt/0006 (revision 6) |
| N1:18 | - | 0000000000000008 | f64:29A0000000000000 | f64:299FFFFFFFFFFFFF | f64:29A0000000000000 (faithful f64:29A0000000000000) | numerics/cbrt/0006 (revision 6) |
| N1:19 | - | 0000000000000009 | f64:29A0A402FCC79298 | f64:29A0A402FCC79297 | f64:29A0A402FCC79298 (faithful f64:29A0A402FCC79298, f64:29A0A402FCC79299) | numerics/cbrt/0006 (revision 6) |
| N1:20 | - | 000000000000000F | f64:29A3BACD6561FF5E | f64:29A3BACD6561FF5C | f64:29A3BACD6561FF5E (faithful f64:29A3BACD6561FF5D, f64:29A3BACD6561FF5E) | numerics/cbrt/0006 (revision 6) |
| N1:23 | - | 000000000000001F | f64:29A9218C2DF27726 | f64:29A9218C2DF27725 | f64:29A9218C2DF27726 (faithful f64:29A9218C2DF27725, f64:29A9218C2DF27726) | numerics/cbrt/0006 (revision 6) |
| N1:25 | - | 0000000000000021 | f64:29A9A907C24108E7 | f64:29A9A907C24108E8 | f64:29A9A907C24108E7 (faithful f64:29A9A907C24108E6, f64:29A9A907C24108E7) | numerics/cbrt/0006 (revision 6) |
| N1:26 | - | 000000000000003F | f64:29AFD51BF2069FE6 | f64:29AFD51BF2069FE7 | f64:29AFD51BF2069FE6 (faithful f64:29AFD51BF2069FE6, f64:29AFD51BF2069FE7) | numerics/cbrt/0006 (revision 6) |
| N1:27 | - | 0000000000000040 | f64:29B0000000000000 | f64:29AFFFFFFFFFFFFF | f64:29B0000000000000 (faithful f64:29B0000000000000) | numerics/cbrt/0006 (revision 6) |
| N1:28 | - | 0000000000000041 | f64:29B01539221D4C97 | f64:29B01539221D4C96 | f64:29B01539221D4C97 (faithful f64:29B01539221D4C97, f64:29B01539221D4C98) | numerics/cbrt/0006 (revision 6) |
| N1:29 | - | 000000000000007F | f64:29B41B298D47800E | f64:29B41B298D47800D | f64:29B41B298D47800E (faithful f64:29B41B298D47800E, f64:29B41B298D47800F) | numerics/cbrt/0006 (revision 6) |
| N1:31 | - | 0000000000000081 | f64:29B4360A7A7D5067 | f64:29B4360A7A7D5066 | f64:29B4360A7A7D5067 (faithful f64:29B4360A7A7D5067, f64:29B4360A7A7D5068) | numerics/cbrt/0006 (revision 6) |
| N1:36 | - | 0000000000000200 | f64:29C0000000000000 | f64:29BFFFFFFFFFFFFF | f64:29C0000000000000 (faithful f64:29C0000000000000) | numerics/cbrt/0006 (revision 6) |
| N1:37 | - | 0000000000000201 | f64:29C002AA39031E91 | f64:29C002AA39031E90 | f64:29C002AA39031E91 (faithful f64:29C002AA39031E91, f64:29C002AA39031E92) | numerics/cbrt/0006 (revision 6) |
| N1:40 | - | 0000000000000401 | f64:29C42A50E350C0AA | f64:29C42A50E350C0AB | f64:29C42A50E350C0AA (faithful f64:29C42A50E350C0AA, f64:29C42A50E350C0AB) | numerics/cbrt/0006 (revision 6) |

## Math.expm1 / J:JSMath.Expm1 / class a / is more than one unit in the last place from the exact value near zero: 794

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:7480 | - | BE2A9549CBA9AF0D | f64:BE2A9549CAF9048A | f64:BE2A9549CAF9048B | f64:BE2A9549CAF9048A (faithful f64:BE2A9549CAF90489, f64:BE2A9549CAF9048A) |  |
| N1:7851 | - | BDBE729CBF757FBE | f64:BDBE729CBF73B036 | f64:BDBE729CBF73B037 | f64:BDBE729CBF73B036 (faithful f64:BDBE729CBF73B035, f64:BDBE729CBF73B036) |  |
| N1:8307 | - | BD42695A1B5DA1A6 | f64:BD42695A1B5DA053 | f64:BD42695A1B5DA052 | f64:BD42695A1B5DA053 (faithful f64:BD42695A1B5DA053, f64:BD42695A1B5DA054) |  |
| N1:15012 | - | BE490E66E57169BB | f64:BE490E66E2FD98D3 | f64:BE490E66E2FD98D4 | f64:BE490E66E2FD98D3 (faithful f64:BE490E66E2FD98D2, f64:BE490E66E2FD98D3) |  |
| N1:15530 | - | 3CC6C6B6E49DC486 | f64:3CC6C6B6E49DC488 | f64:3CC6C6B6E49DC487 | f64:3CC6C6B6E49DC488 (faithful f64:3CC6C6B6E49DC488, f64:3CC6C6B6E49DC489) |  |
| N1:16722 | - | BCAC35D5749A75CD | f64:BCAC35D5749A75CC | f64:BCAC35D5749A75CB | f64:BCAC35D5749A75CC (faithful f64:BCAC35D5749A75CC, f64:BCAC35D5749A75CD) |  |
| N1:17208 | - | 3CF46F3DB4115CCD | f64:3CF46F3DB4115CDA | f64:3CF46F3DB4115CD9 | f64:3CF46F3DB4115CDA (faithful f64:3CF46F3DB4115CDA, f64:3CF46F3DB4115CDB) |  |
| N1:19169 | - | 3E7BDA37066BCD32 | f64:3E7BDA371EA9DA29 | f64:3E7BDA371EA9DA2A | f64:3E7BDA371EA9DA29 (faithful f64:3E7BDA371EA9DA28, f64:3E7BDA371EA9DA29) |  |
| N1:20180 | - | 3D716DD33E78732B | f64:3D716DD33E787CA9 | f64:3D716DD33E787CA8 | f64:3D716DD33E787CA9 (faithful f64:3D716DD33E787CA9, f64:3D716DD33E787CAA) |  |
| N1:22375 | - | 3E4BB2EBFE033E96 | f64:3E4BB2EC0102796B | f64:3E4BB2EC0102796C | f64:3E4BB2EC0102796B (faithful f64:3E4BB2EC0102796A, f64:3E4BB2EC0102796B) |  |
| N1:23788 | - | BD96EC8085EC837A | f64:BD96EC8085EC41CA | f64:BD96EC8085EC41CB | f64:BD96EC8085EC41CA (faithful f64:BD96EC8085EC41C9, f64:BD96EC8085EC41CA) |  |
| N1:25743 | - | 3D408DF147D37644 | f64:3D408DF147D37756 | f64:3D408DF147D37755 | f64:3D408DF147D37756 (faithful f64:3D408DF147D37756, f64:3D408DF147D37757) |  |
| N1:26818 | - | BCAB4481154FDAE2 | f64:BCAB4481154FDAE1 | f64:BCAB4481154FDAE0 | f64:BCAB4481154FDAE1 (faithful f64:BCAB4481154FDAE1, f64:BCAB4481154FDAE2) |  |
| N1:28193 | - | 3E5B85FB44DFC187 | f64:3E5B85FB4ACAD3C7 | f64:3E5B85FB4ACAD3C8 | f64:3E5B85FB4ACAD3C7 (faithful f64:3E5B85FB4ACAD3C6, f64:3E5B85FB4ACAD3C7) |  |
| N1:28453 | - | BCD8F3E3B2F6A34E | f64:BCD8F3E3B2F6A349 | f64:BCD8F3E3B2F6A348 | f64:BCD8F3E3B2F6A349 (faithful f64:BCD8F3E3B2F6A349, f64:BCD8F3E3B2F6A34A) |  |
| N1:29159 | - | BDBD744B90316022 | f64:BDBD744B902FAE5B | f64:BDBD744B902FAE5A | f64:BDBD744B902FAE5B (faithful f64:BDBD744B902FAE5B, f64:BDBD744B902FAE5C) |  |
| N1:29760 | - | BE56A8BCB7930A50 | f64:BE56A8BCB3902B01 | f64:BE56A8BCB3902B02 | f64:BE56A8BCB3902B01 (faithful f64:BE56A8BCB3902B00, f64:BE56A8BCB3902B01) |  |
| N1:30086 | - | BCB78C41B745B73A | f64:BCB78C41B745B739 | f64:BCB78C41B745B73A | f64:BCB78C41B745B739 (faithful f64:BCB78C41B745B738, f64:BCB78C41B745B739) |  |
| N1:30689 | - | BCA84EE6811C8A55 | f64:BCA84EE6811C8A54 | f64:BCA84EE6811C8A53 | f64:BCA84EE6811C8A54 (faithful f64:BCA84EE6811C8A54, f64:BCA84EE6811C8A55) |  |
| N1:34014 | - | BDEE9F6FD2B02C10 | f64:BDEE9F6FD2A1850A | f64:BDEE9F6FD2A1850B | f64:BDEE9F6FD2A1850A (faithful f64:BDEE9F6FD2A18509, f64:BDEE9F6FD2A1850A) |  |

## Math.expm1 / J:JSMath.Expm1 / class b / both admitted: 21911

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:3071 | - | 3CA0000000000001 | f64:3CA0000000000001 | f64:3CA0000000000002 | f64:3CA0000000000001 (faithful f64:3CA0000000000001, f64:3CA0000000000002) | numerics/expm1/0006 (revision 6) |
| N1:3073 | - | 3CB0000000000000 | f64:3CB0000000000000 | f64:3CB0000000000001 | f64:3CB0000000000001 (faithful f64:3CB0000000000000, f64:3CB0000000000001) | numerics/expm1/0006 (revision 6) |
| N1:3075 | - | 3CBFFFFFFFFFFFFF | f64:3CC0000000000000 | f64:3CC0000000000001 | f64:3CC0000000000000 (faithful f64:3CC0000000000000, f64:3CC0000000000001) | numerics/expm1/0006 (revision 6) |
| N1:3150 | - | 3E4FFFFFFFFFFFFF | f64:3E50000002000000 | f64:3E50000001FFFFFF | f64:3E50000002000000 (faithful f64:3E50000001FFFFFF, f64:3E50000002000000) | numerics/expm1/0006 (revision 6) |
| N1:3152 | - | 3E50000000000001 | f64:3E50000002000001 | f64:3E50000002000002 | f64:3E50000002000001 (faithful f64:3E50000002000001, f64:3E50000002000002) | numerics/expm1/0006 (revision 6) |
| N1:3181 | - | 3EF0000000000000 | f64:3EF000080002AAAB | f64:3EF000080002AAAC | f64:3EF000080002AAAB (faithful f64:3EF000080002AAAB, f64:3EF000080002AAAC) | numerics/expm1/0006 (revision 6) |
| N1:3182 | - | 3EF0000000000001 | f64:3EF000080002AAAC | f64:3EF000080002AAAD | f64:3EF000080002AAAC (faithful f64:3EF000080002AAAC, f64:3EF000080002AAAD) | numerics/expm1/0006 (revision 6) |
| N1:3183 | - | 3EFFFFFFFFFFFFFF | f64:3F000010000AAAB0 | f64:3F000010000AAAAF | f64:3F000010000AAAB0 (faithful f64:3F000010000AAAAF, f64:3F000010000AAAB0) | numerics/expm1/0006 (revision 6) |
| N1:3187 | - | 3F10000000000000 | f64:3F100020002AAAD5 | f64:3F100020002AAAD6 | f64:3F100020002AAAD5 (faithful f64:3F100020002AAAD5, f64:3F100020002AAAD6) | numerics/expm1/0006 (revision 6) |
| N1:3188 | - | 3F10000000000001 | f64:3F100020002AAAD6 | f64:3F100020002AAAD7 | f64:3F100020002AAAD6 (faithful f64:3F100020002AAAD6, f64:3F100020002AAAD7) | numerics/expm1/0006 (revision 6) |
| N1:3189 | - | 3F1FFFFFFFFFFFFF | f64:3F20004000AAAC00 | f64:3F20004000AAABFF | f64:3F20004000AAAC00 (faithful f64:3F20004000AAABFF, f64:3F20004000AAAC00) | numerics/expm1/0006 (revision 6) |
| N1:3192 | - | 3F2FFFFFFFFFFFFF | f64:3F30008002AAB555 | f64:3F30008002AAB554 | f64:3F30008002AAB555 (faithful f64:3F30008002AAB554, f64:3F30008002AAB555) | numerics/expm1/0006 (revision 6) |
| N1:3195 | - | 3F3FFFFFFFFFFFFF | f64:3F4001000AAB0002 | f64:3F4001000AAB0001 | f64:3F4001000AAB0002 (faithful f64:3F4001000AAB0001, f64:3F4001000AAB0002) | numerics/expm1/0006 (revision 6) |
| N1:3198 | - | 3F4FFFFFFFFFFFFF | f64:3F5002002AAD5577 | f64:3F5002002AAD5576 | f64:3F5002002AAD5577 (faithful f64:3F5002002AAD5576, f64:3F5002002AAD5577) | numerics/expm1/0006 (revision 6) |
| N1:3201 | - | 3F5FFFFFFFFFFFFF | f64:3F600400AAC00222 | f64:3F600400AAC00221 | f64:3F600400AAC00222 (faithful f64:3F600400AAC00221, f64:3F600400AAC00222) | numerics/expm1/0006 (revision 6) |
| N1:3204 | - | 3F6FFFFFFFFFFFFF | f64:3F700802AB55777D | f64:3F700802AB55777C | f64:3F700802AB55777D (faithful f64:3F700802AB55777C, f64:3F700802AB55777D) | numerics/expm1/0006 (revision 6) |
| N1:3208 | - | 3F80000000000000 | f64:3F80100AB00222D8 | f64:3F80100AB00222D9 | f64:3F80100AB00222D8 (faithful f64:3F80100AB00222D8, f64:3F80100AB00222D9) | numerics/expm1/0006 (revision 6) |
| N1:3209 | - | 3F80000000000001 | f64:3F80100AB00222D9 | f64:3F80100AB00222DA | f64:3F80100AB00222D9 (faithful f64:3F80100AB00222D9, f64:3F80100AB00222DA) | numerics/expm1/0006 (revision 6) |
| N1:3214 | - | 3FA0000000000000 | f64:3FA040AC0224FD93 | f64:3FA040AC0224FD94 | f64:3FA040AC0224FD93 (faithful f64:3FA040AC0224FD93, f64:3FA040AC0224FD94) | numerics/expm1/0006 (revision 6) |
| N1:3215 | - | 3FA0000000000001 | f64:3FA040AC0224FD94 | f64:3FA040AC0224FD95 | f64:3FA040AC0224FD94 (faithful f64:3FA040AC0224FD94, f64:3FA040AC0224FD95) | numerics/expm1/0006 (revision 6) |

## Math.expm1 / V:JsRealm.MathExpMinusOne / class a / is more than one unit in the last place from the exact value near zero: 518694

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:2 | - | 0000000000000001 | f64:0000000000000001 | f64:0000000000000000 | f64:0000000000000001 (faithful f64:0000000000000001, f64:0000000000000002) |  |
| N1:3 | - | 8000000000000001 | f64:8000000000000001 | f64:0000000000000000 | f64:8000000000000001 (faithful f64:8000000000000000, f64:8000000000000001) |  |
| N1:4 | - | 000FFFFFFFFFFFFF | f64:000FFFFFFFFFFFFF | f64:0000000000000000 | f64:000FFFFFFFFFFFFF (faithful f64:000FFFFFFFFFFFFF, f64:0010000000000000) |  |
| N1:5 | - | 800FFFFFFFFFFFFF | f64:800FFFFFFFFFFFFF | f64:0000000000000000 | f64:800FFFFFFFFFFFFF (faithful f64:800FFFFFFFFFFFFE, f64:800FFFFFFFFFFFFF) |  |
| N1:6 | - | 0010000000000000 | f64:0010000000000000 | f64:0000000000000000 | f64:0010000000000000 (faithful f64:0010000000000000, f64:0010000000000001) |  |
| N1:7 | - | 8010000000000000 | f64:8010000000000000 | f64:0000000000000000 | f64:8010000000000000 (faithful f64:800FFFFFFFFFFFFF, f64:8010000000000000) |  |
| N1:13 | - | 0000000000000002 | f64:0000000000000002 | f64:0000000000000000 | f64:0000000000000002 (faithful f64:0000000000000002, f64:0000000000000003) |  |
| N1:14 | - | 0000000000000003 | f64:0000000000000003 | f64:0000000000000000 | f64:0000000000000003 (faithful f64:0000000000000003, f64:0000000000000004) |  |
| N1:15 | - | 0000000000000004 | f64:0000000000000004 | f64:0000000000000000 | f64:0000000000000004 (faithful f64:0000000000000004, f64:0000000000000005) |  |
| N1:16 | - | 0000000000000005 | f64:0000000000000005 | f64:0000000000000000 | f64:0000000000000005 (faithful f64:0000000000000005, f64:0000000000000006) |  |
| N1:17 | - | 0000000000000007 | f64:0000000000000007 | f64:0000000000000000 | f64:0000000000000007 (faithful f64:0000000000000007, f64:0000000000000008) |  |
| N1:18 | - | 0000000000000008 | f64:0000000000000008 | f64:0000000000000000 | f64:0000000000000008 (faithful f64:0000000000000008, f64:0000000000000009) |  |
| N1:19 | - | 0000000000000009 | f64:0000000000000009 | f64:0000000000000000 | f64:0000000000000009 (faithful f64:0000000000000009, f64:000000000000000A) |  |
| N1:20 | - | 000000000000000F | f64:000000000000000F | f64:0000000000000000 | f64:000000000000000F (faithful f64:000000000000000F, f64:0000000000000010) |  |
| N1:21 | - | 0000000000000010 | f64:0000000000000010 | f64:0000000000000000 | f64:0000000000000010 (faithful f64:0000000000000010, f64:0000000000000011) |  |
| N1:22 | - | 0000000000000011 | f64:0000000000000011 | f64:0000000000000000 | f64:0000000000000011 (faithful f64:0000000000000011, f64:0000000000000012) |  |
| N1:23 | - | 000000000000001F | f64:000000000000001F | f64:0000000000000000 | f64:000000000000001F (faithful f64:000000000000001F, f64:0000000000000020) |  |
| N1:24 | - | 0000000000000020 | f64:0000000000000020 | f64:0000000000000000 | f64:0000000000000020 (faithful f64:0000000000000020, f64:0000000000000021) |  |
| N1:25 | - | 0000000000000021 | f64:0000000000000021 | f64:0000000000000000 | f64:0000000000000021 (faithful f64:0000000000000021, f64:0000000000000022) |  |
| N1:26 | - | 000000000000003F | f64:000000000000003F | f64:0000000000000000 | f64:000000000000003F (faithful f64:000000000000003F, f64:0000000000000040) |  |

## Math.expm1 / V:JsRealm.MathExpMinusOne / class b / both admitted: 13969

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:3154 | - | 3E60000000000000 | f64:3E60000004000001 | f64:3E60000004000000 | f64:3E60000004000001 (faithful f64:3E60000004000000, f64:3E60000004000001) | numerics/expm1/0006 (revision 6) |
| N1:3169 | - | 3EB0000000000000 | f64:3EB00000800002AB | f64:3EB0000080000000 | f64:3EB00000800002AB (faithful f64:3EB00000800002AA, f64:3EB00000800002AB) | numerics/expm1/0006 (revision 6) |
| N1:3170 | - | 3EB0000000000001 | f64:3EB00000800002AC | f64:3EB0000080000000 | f64:3EB00000800002AC (faithful f64:3EB00000800002AB, f64:3EB00000800002AC) | numerics/expm1/0006 (revision 6) |
| N1:3171 | - | 3EBFFFFFFFFFFFFF | f64:3EC0000100000AAA | f64:3EC0000100000000 | f64:3EC0000100000AAA (faithful f64:3EC0000100000AAA, f64:3EC0000100000AAB) | numerics/expm1/0006 (revision 6) |
| N1:3172 | - | 3EC0000000000000 | f64:3EC0000100000AAB | f64:3EC0000100000000 | f64:3EC0000100000AAB (faithful f64:3EC0000100000AAA, f64:3EC0000100000AAB) | numerics/expm1/0006 (revision 6) |
| N1:3173 | - | 3EC0000000000001 | f64:3EC0000100000AAC | f64:3EC0000100000000 | f64:3EC0000100000AAC (faithful f64:3EC0000100000AAB, f64:3EC0000100000AAC) | numerics/expm1/0006 (revision 6) |
| N1:3174 | - | 3ECFFFFFFFFFFFFF | f64:3ED0000200002AAA | f64:3ED0000200000000 | f64:3ED0000200002AAA (faithful f64:3ED0000200002AAA, f64:3ED0000200002AAB) | numerics/expm1/0006 (revision 6) |
| N1:3175 | - | 3ED0000000000000 | f64:3ED0000200002AAB | f64:3ED0000200000000 | f64:3ED0000200002AAB (faithful f64:3ED0000200002AAA, f64:3ED0000200002AAB) | numerics/expm1/0006 (revision 6) |
| N1:3176 | - | 3ED0000000000001 | f64:3ED0000200002AAC | f64:3ED0000200000000 | f64:3ED0000200002AAC (faithful f64:3ED0000200002AAB, f64:3ED0000200002AAC) | numerics/expm1/0006 (revision 6) |
| N1:3177 | - | 3EDFFFFFFFFFFFFF | f64:3EE000040000AAAA | f64:3EE0000400000000 | f64:3EE000040000AAAA (faithful f64:3EE000040000AAAA, f64:3EE000040000AAAB) | numerics/expm1/0006 (revision 6) |
| N1:3178 | - | 3EE0000000000000 | f64:3EE000040000AAAB | f64:3EE0000400000000 | f64:3EE000040000AAAB (faithful f64:3EE000040000AAAA, f64:3EE000040000AAAB) | numerics/expm1/0006 (revision 6) |
| N1:3179 | - | 3EE0000000000001 | f64:3EE000040000AAAC | f64:3EE0000400000000 | f64:3EE000040000AAAC (faithful f64:3EE000040000AAAB, f64:3EE000040000AAAC) | numerics/expm1/0006 (revision 6) |
| N1:3180 | - | 3EEFFFFFFFFFFFFF | f64:3EF000080002AAAB | f64:3EF0000800030000 | f64:3EF000080002AAAB (faithful f64:3EF000080002AAAA, f64:3EF000080002AAAB) | numerics/expm1/0006 (revision 6) |
| N1:3181 | - | 3EF0000000000000 | f64:3EF000080002AAAB | f64:3EF0000800030000 | f64:3EF000080002AAAB (faithful f64:3EF000080002AAAB, f64:3EF000080002AAAC) | numerics/expm1/0006 (revision 6) |
| N1:3182 | - | 3EF0000000000001 | f64:3EF000080002AAAC | f64:3EF0000800030000 | f64:3EF000080002AAAC (faithful f64:3EF000080002AAAC, f64:3EF000080002AAAD) | numerics/expm1/0006 (revision 6) |
| N1:3183 | - | 3EFFFFFFFFFFFFFF | f64:3F000010000AAAB0 | f64:3F000010000A8000 | f64:3F000010000AAAB0 (faithful f64:3F000010000AAAAF, f64:3F000010000AAAB0) | numerics/expm1/0006 (revision 6) |
| N1:3184 | - | 3F00000000000000 | f64:3F000010000AAAB0 | f64:3F000010000A8000 | f64:3F000010000AAAB0 (faithful f64:3F000010000AAAB0, f64:3F000010000AAAB1) | numerics/expm1/0006 (revision 6) |
| N1:3185 | - | 3F00000000000001 | f64:3F000010000AAAB1 | f64:3F000010000A8000 | f64:3F000010000AAAB1 (faithful f64:3F000010000AAAB1, f64:3F000010000AAAB2) | numerics/expm1/0006 (revision 6) |
| N1:3186 | - | 3F0FFFFFFFFFFFFF | f64:3F100020002AAAD5 | f64:3F100020002AC000 | f64:3F100020002AAAD5 (faithful f64:3F100020002AAAD4, f64:3F100020002AAAD5) | numerics/expm1/0006 (revision 6) |
| N1:3187 | - | 3F10000000000000 | f64:3F100020002AAAD5 | f64:3F100020002AC000 | f64:3F100020002AAAD5 (faithful f64:3F100020002AAAD5, f64:3F100020002AAAD6) | numerics/expm1/0006 (revision 6) |

## Math.hypot / J:JSMath.Hypot / class b / both admitted: 13701

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N3H:96 | - | 3FE0000000000000,4008000000000000 | f64:400854BFB363DC39 | f64:400854BFB363DC38 | f64:400854BFB363DC39 (faithful f64:400854BFB363DC39, f64:400854BFB363DC3A) | numerics/hypot/0011 (revision 6) |
| N3H:97 | - | 3FE0000000000000,C008000000000000 | f64:400854BFB363DC39 | f64:400854BFB363DC38 | f64:400854BFB363DC39 (faithful f64:400854BFB363DC39, f64:400854BFB363DC3A) | numerics/hypot/0011 (revision 6) |
| N3H:118 | - | BFE0000000000000,4008000000000000 | f64:400854BFB363DC39 | f64:400854BFB363DC38 | f64:400854BFB363DC39 (faithful f64:400854BFB363DC39, f64:400854BFB363DC3A) | numerics/hypot/0011 (revision 6) |
| N3H:119 | - | BFE0000000000000,C008000000000000 | f64:400854BFB363DC39 | f64:400854BFB363DC38 | f64:400854BFB363DC39 (faithful f64:400854BFB363DC39, f64:400854BFB363DC3A) | numerics/hypot/0011 (revision 6) |
| N3H:140 | - | 4000000000000000,4008000000000000 | f64:400CD82B446159F3 | f64:400CD82B446159F4 | f64:400CD82B446159F3 (faithful f64:400CD82B446159F3, f64:400CD82B446159F4) | numerics/hypot/0011 (revision 6) |
| N3H:141 | - | 4000000000000000,C008000000000000 | f64:400CD82B446159F3 | f64:400CD82B446159F4 | f64:400CD82B446159F3 (faithful f64:400CD82B446159F3, f64:400CD82B446159F4) | numerics/hypot/0011 (revision 6) |
| N3H:162 | - | C000000000000000,4008000000000000 | f64:400CD82B446159F3 | f64:400CD82B446159F4 | f64:400CD82B446159F3 (faithful f64:400CD82B446159F3, f64:400CD82B446159F4) | numerics/hypot/0011 (revision 6) |
| N3H:163 | - | C000000000000000,C008000000000000 | f64:400CD82B446159F3 | f64:400CD82B446159F4 | f64:400CD82B446159F3 (faithful f64:400CD82B446159F3, f64:400CD82B446159F4) | numerics/hypot/0011 (revision 6) |
| N3H:180 | - | 4008000000000000,3FE0000000000000 | f64:400854BFB363DC39 | f64:400854BFB363DC38 | f64:400854BFB363DC39 (faithful f64:400854BFB363DC39, f64:400854BFB363DC3A) | numerics/hypot/0011 (revision 6) |
| N3H:181 | - | 4008000000000000,BFE0000000000000 | f64:400854BFB363DC39 | f64:400854BFB363DC38 | f64:400854BFB363DC39 (faithful f64:400854BFB363DC39, f64:400854BFB363DC3A) | numerics/hypot/0011 (revision 6) |
| N3H:182 | - | 4008000000000000,4000000000000000 | f64:400CD82B446159F3 | f64:400CD82B446159F4 | f64:400CD82B446159F3 (faithful f64:400CD82B446159F3, f64:400CD82B446159F4) | numerics/hypot/0011 (revision 6) |
| N3H:183 | - | 4008000000000000,C000000000000000 | f64:400CD82B446159F3 | f64:400CD82B446159F4 | f64:400CD82B446159F3 (faithful f64:400CD82B446159F3, f64:400CD82B446159F4) | numerics/hypot/0011 (revision 6) |
| N3H:184 | - | 4008000000000000,4008000000000000 | f64:4010F876CCDF6CD9 | f64:4010F876CCDF6CDA | f64:4010F876CCDF6CD9 (faithful f64:4010F876CCDF6CD9, f64:4010F876CCDF6CDA) | numerics/hypot/0011 (revision 6) |
| N3H:185 | - | 4008000000000000,C008000000000000 | f64:4010F876CCDF6CD9 | f64:4010F876CCDF6CDA | f64:4010F876CCDF6CD9 (faithful f64:4010F876CCDF6CD9, f64:4010F876CCDF6CDA) | numerics/hypot/0011 (revision 6) |
| N3H:202 | - | C008000000000000,3FE0000000000000 | f64:400854BFB363DC39 | f64:400854BFB363DC38 | f64:400854BFB363DC39 (faithful f64:400854BFB363DC39, f64:400854BFB363DC3A) | numerics/hypot/0011 (revision 6) |
| N3H:203 | - | C008000000000000,BFE0000000000000 | f64:400854BFB363DC39 | f64:400854BFB363DC38 | f64:400854BFB363DC39 (faithful f64:400854BFB363DC39, f64:400854BFB363DC3A) | numerics/hypot/0011 (revision 6) |
| N3H:204 | - | C008000000000000,4000000000000000 | f64:400CD82B446159F3 | f64:400CD82B446159F4 | f64:400CD82B446159F3 (faithful f64:400CD82B446159F3, f64:400CD82B446159F4) | numerics/hypot/0011 (revision 6) |
| N3H:205 | - | C008000000000000,C000000000000000 | f64:400CD82B446159F3 | f64:400CD82B446159F4 | f64:400CD82B446159F3 (faithful f64:400CD82B446159F3, f64:400CD82B446159F4) | numerics/hypot/0011 (revision 6) |
| N3H:206 | - | C008000000000000,4008000000000000 | f64:4010F876CCDF6CD9 | f64:4010F876CCDF6CDA | f64:4010F876CCDF6CD9 (faithful f64:4010F876CCDF6CD9, f64:4010F876CCDF6CDA) | numerics/hypot/0011 (revision 6) |
| N3H:207 | - | C008000000000000,C008000000000000 | f64:4010F876CCDF6CD9 | f64:4010F876CCDF6CDA | f64:4010F876CCDF6CD9 (faithful f64:4010F876CCDF6CD9, f64:4010F876CCDF6CDA) | numerics/hypot/0011 (revision 6) |

## Math.hypot / V:JsRealm.MathHypotenuse / class b / both admitted: 10562

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N3H:96 | - | 3FE0000000000000,4008000000000000 | f64:400854BFB363DC39 | f64:400854BFB363DC38 | f64:400854BFB363DC39 (faithful f64:400854BFB363DC39, f64:400854BFB363DC3A) | numerics/hypot/0011 (revision 6) |
| N3H:97 | - | 3FE0000000000000,C008000000000000 | f64:400854BFB363DC39 | f64:400854BFB363DC38 | f64:400854BFB363DC39 (faithful f64:400854BFB363DC39, f64:400854BFB363DC3A) | numerics/hypot/0011 (revision 6) |
| N3H:118 | - | BFE0000000000000,4008000000000000 | f64:400854BFB363DC39 | f64:400854BFB363DC38 | f64:400854BFB363DC39 (faithful f64:400854BFB363DC39, f64:400854BFB363DC3A) | numerics/hypot/0011 (revision 6) |
| N3H:119 | - | BFE0000000000000,C008000000000000 | f64:400854BFB363DC39 | f64:400854BFB363DC38 | f64:400854BFB363DC39 (faithful f64:400854BFB363DC39, f64:400854BFB363DC3A) | numerics/hypot/0011 (revision 6) |
| N3H:140 | - | 4000000000000000,4008000000000000 | f64:400CD82B446159F3 | f64:400CD82B446159F4 | f64:400CD82B446159F3 (faithful f64:400CD82B446159F3, f64:400CD82B446159F4) | numerics/hypot/0011 (revision 6) |
| N3H:141 | - | 4000000000000000,C008000000000000 | f64:400CD82B446159F3 | f64:400CD82B446159F4 | f64:400CD82B446159F3 (faithful f64:400CD82B446159F3, f64:400CD82B446159F4) | numerics/hypot/0011 (revision 6) |
| N3H:162 | - | C000000000000000,4008000000000000 | f64:400CD82B446159F3 | f64:400CD82B446159F4 | f64:400CD82B446159F3 (faithful f64:400CD82B446159F3, f64:400CD82B446159F4) | numerics/hypot/0011 (revision 6) |
| N3H:163 | - | C000000000000000,C008000000000000 | f64:400CD82B446159F3 | f64:400CD82B446159F4 | f64:400CD82B446159F3 (faithful f64:400CD82B446159F3, f64:400CD82B446159F4) | numerics/hypot/0011 (revision 6) |
| N3H:180 | - | 4008000000000000,3FE0000000000000 | f64:400854BFB363DC39 | f64:400854BFB363DC38 | f64:400854BFB363DC39 (faithful f64:400854BFB363DC39, f64:400854BFB363DC3A) | numerics/hypot/0011 (revision 6) |
| N3H:181 | - | 4008000000000000,BFE0000000000000 | f64:400854BFB363DC39 | f64:400854BFB363DC38 | f64:400854BFB363DC39 (faithful f64:400854BFB363DC39, f64:400854BFB363DC3A) | numerics/hypot/0011 (revision 6) |
| N3H:182 | - | 4008000000000000,4000000000000000 | f64:400CD82B446159F3 | f64:400CD82B446159F4 | f64:400CD82B446159F3 (faithful f64:400CD82B446159F3, f64:400CD82B446159F4) | numerics/hypot/0011 (revision 6) |
| N3H:183 | - | 4008000000000000,C000000000000000 | f64:400CD82B446159F3 | f64:400CD82B446159F4 | f64:400CD82B446159F3 (faithful f64:400CD82B446159F3, f64:400CD82B446159F4) | numerics/hypot/0011 (revision 6) |
| N3H:184 | - | 4008000000000000,4008000000000000 | f64:4010F876CCDF6CD9 | f64:4010F876CCDF6CDA | f64:4010F876CCDF6CD9 (faithful f64:4010F876CCDF6CD9, f64:4010F876CCDF6CDA) | numerics/hypot/0011 (revision 6) |
| N3H:185 | - | 4008000000000000,C008000000000000 | f64:4010F876CCDF6CD9 | f64:4010F876CCDF6CDA | f64:4010F876CCDF6CD9 (faithful f64:4010F876CCDF6CD9, f64:4010F876CCDF6CDA) | numerics/hypot/0011 (revision 6) |
| N3H:202 | - | C008000000000000,3FE0000000000000 | f64:400854BFB363DC39 | f64:400854BFB363DC38 | f64:400854BFB363DC39 (faithful f64:400854BFB363DC39, f64:400854BFB363DC3A) | numerics/hypot/0011 (revision 6) |
| N3H:203 | - | C008000000000000,BFE0000000000000 | f64:400854BFB363DC39 | f64:400854BFB363DC38 | f64:400854BFB363DC39 (faithful f64:400854BFB363DC39, f64:400854BFB363DC3A) | numerics/hypot/0011 (revision 6) |
| N3H:204 | - | C008000000000000,4000000000000000 | f64:400CD82B446159F3 | f64:400CD82B446159F4 | f64:400CD82B446159F3 (faithful f64:400CD82B446159F3, f64:400CD82B446159F4) | numerics/hypot/0011 (revision 6) |
| N3H:205 | - | C008000000000000,C000000000000000 | f64:400CD82B446159F3 | f64:400CD82B446159F4 | f64:400CD82B446159F3 (faithful f64:400CD82B446159F3, f64:400CD82B446159F4) | numerics/hypot/0011 (revision 6) |
| N3H:206 | - | C008000000000000,4008000000000000 | f64:4010F876CCDF6CD9 | f64:4010F876CCDF6CDA | f64:4010F876CCDF6CD9 (faithful f64:4010F876CCDF6CD9, f64:4010F876CCDF6CDA) | numerics/hypot/0011 (revision 6) |
| N3H:207 | - | C008000000000000,C008000000000000 | f64:4010F876CCDF6CD9 | f64:4010F876CCDF6CDA | f64:4010F876CCDF6CD9 (faithful f64:4010F876CCDF6CD9, f64:4010F876CCDF6CDA) | numerics/hypot/0011 (revision 6) |

## Math.log1p / J:JSMath.Log1p / class a / is more than one unit in the last place from the exact value near zero: 367

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:8771 | - | BD7903321B65087B | f64:BD7903321B651C08 | f64:BD7903321B651C09 | f64:BD7903321B651C08 (faithful f64:BD7903321B651C07, f64:BD7903321B651C08) |  |
| N1:12825 | - | BCD3C95EE6C44B36 | f64:BCD3C95EE6C44B39 | f64:BCD3C95EE6C44B38 | f64:BCD3C95EE6C44B39 (faithful f64:BCD3C95EE6C44B39, f64:BCD3C95EE6C44B3A) |  |
| N1:16416 | - | BDA973E80B1E3BC3 | f64:BDA973E80B1EDDB9 | f64:BDA973E80B1EDDBA | f64:BDA973E80B1EDDB9 (faithful f64:BDA973E80B1EDDB8, f64:BDA973E80B1EDDB9) |  |
| N1:21014 | - | BD76B0FDB140E7E6 | f64:BD76B0FDB140F7FD | f64:BD76B0FDB140F7FC | f64:BD76B0FDB140F7FD (faithful f64:BD76B0FDB140F7FD, f64:BD76B0FDB140F7FE) |  |
| N1:21122 | - | BDEECF86217CCF79 | f64:BDEECF86218BA4A8 | f64:BDEECF86218BA4A9 | f64:BDEECF86218BA4A8 (faithful f64:BDEECF86218BA4A7, f64:BDEECF86218BA4A8) |  |
| N1:22891 | - | BE36A972CCE96440 | f64:BE36A972CDEA2C32 | f64:BE36A972CDEA2C31 | f64:BE36A972CDEA2C32 (faithful f64:BE36A972CDEA2C32, f64:BE36A972CDEA2C33) |  |
| N1:25361 | - | BD6B25FD6B2BDD25 | f64:BD6B25FD6B2BE8A9 | f64:BD6B25FD6B2BE8A8 | f64:BD6B25FD6B2BE8A9 (faithful f64:BD6B25FD6B2BE8A9, f64:BD6B25FD6B2BE8AA) |  |
| N1:25552 | - | BE8EB8F397C3C5F0 | f64:BE8EB8F3D2C1B1F1 | f64:BE8EB8F3D2C1B1F0 | f64:BE8EB8F3D2C1B1F1 (faithful f64:BE8EB8F3D2C1B1F1, f64:BE8EB8F3D2C1B1F2) |  |
| N1:35873 | - | BD5D945A7C8FD434 | f64:BD5D945A7C8FDB0A | f64:BD5D945A7C8FDB0B | f64:BD5D945A7C8FDB0A (faithful f64:BD5D945A7C8FDB09, f64:BD5D945A7C8FDB0A) |  |
| N1:41049 | - | BD4918E0B383D696 | f64:BD4918E0B383D90C | f64:BD4918E0B383D90D | f64:BD4918E0B383D90C (faithful f64:BD4918E0B383D90B, f64:BD4918E0B383D90C) |  |
| N1:47514 | - | BDCF5DE86FDA6394 | f64:BDCF5DE86FDE3B75 | f64:BDCF5DE86FDE3B76 | f64:BDCF5DE86FDE3B75 (faithful f64:BDCF5DE86FDE3B74, f64:BDCF5DE86FDE3B75) |  |
| N1:48620 | - | BD265E1DB6388F6C | f64:BD265E1DB6388FE9 | f64:BD265E1DB6388FE8 | f64:BD265E1DB6388FE9 (faithful f64:BD265E1DB6388FE9, f64:BD265E1DB6388FEA) |  |
| N1:49463 | - | BCD3AA0AA6ED6F15 | f64:BCD3AA0AA6ED6F18 | f64:BCD3AA0AA6ED6F17 | f64:BCD3AA0AA6ED6F18 (faithful f64:BCD3AA0AA6ED6F18, f64:BCD3AA0AA6ED6F19) |  |
| N1:52192 | - | BDEDB91A000FD551 | f64:BDEDB91A001DA328 | f64:BDEDB91A001DA329 | f64:BDEDB91A001DA328 (faithful f64:BDEDB91A001DA327, f64:BDEDB91A001DA328) |  |
| N1:53431 | - | BD59ABC68F536A89 | f64:BD59ABC68F536FAF | f64:BD59ABC68F536FAE | f64:BD59ABC68F536FAF (faithful f64:BD59ABC68F536FAF, f64:BD59ABC68F536FB0) |  |
| N1:53640 | - | BDCD9398F6170730 | f64:BDCD9398F61A71F6 | f64:BDCD9398F61A71F7 | f64:BDCD9398F61A71F6 (faithful f64:BDCD9398F61A71F5, f64:BDCD9398F61A71F6) |  |
| N1:54423 | - | BE7EB6A9A3B22903 | f64:BE7EB6A9C12CB9E9 | f64:BE7EB6A9C12CB9EA | f64:BE7EB6A9C12CB9E9 (faithful f64:BE7EB6A9C12CB9E8, f64:BE7EB6A9C12CB9E9) |  |
| N1:54731 | - | BD1BB6E83C7FDEC4 | f64:BD1BB6E83C7FDF24 | f64:BD1BB6E83C7FDF23 | f64:BD1BB6E83C7FDF24 (faithful f64:BD1BB6E83C7FDF24, f64:BD1BB6E83C7FDF25) |  |
| N1:61771 | - | BDC5739750AA5ECB | f64:BDC5739750AC2AF6 | f64:BDC5739750AC2AF5 | f64:BDC5739750AC2AF6 (faithful f64:BDC5739750AC2AF6, f64:BDC5739750AC2AF7) |  |
| N1:63668 | - | BEA7E50B1E1559C2 | f64:BEA7E50BACD29946 | f64:BEA7E50BACD29947 | f64:BEA7E50BACD29946 (faithful f64:BEA7E50BACD29945, f64:BEA7E50BACD29946) |  |

## Math.log1p / J:JSMath.Log1p / class b / both admitted: 11496

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:3207 | - | 3F7FFFFFFFFFFFFF | f64:3F7FE02A6B106788 | f64:3F7FE02A6B10678A | f64:3F7FE02A6B106788 (faithful f64:3F7FE02A6B106787, f64:3F7FE02A6B106788) | numerics/log1p/0006 (revision 6) |
| N1:3208 | - | 3F80000000000000 | f64:3F7FE02A6B106789 | f64:3F7FE02A6B10678B | f64:3F7FE02A6B106789 (faithful f64:3F7FE02A6B106788, f64:3F7FE02A6B106789) | numerics/log1p/0006 (revision 6) |
| N1:3209 | - | 3F80000000000001 | f64:3F7FE02A6B10678B | f64:3F7FE02A6B10678D | f64:3F7FE02A6B10678B (faithful f64:3F7FE02A6B10678A, f64:3F7FE02A6B10678B) | numerics/log1p/0006 (revision 6) |
| N1:3210 | - | 3F8FFFFFFFFFFFFF | f64:3F8FC0A8B0FC03E3 | f64:3F8FC0A8B0FC03E4 | f64:3F8FC0A8B0FC03E3 (faithful f64:3F8FC0A8B0FC03E2, f64:3F8FC0A8B0FC03E3) | numerics/log1p/0006 (revision 6) |
| N1:3212 | - | 3F90000000000001 | f64:3F8FC0A8B0FC03E6 | f64:3F8FC0A8B0FC03E4 | f64:3F8FC0A8B0FC03E6 (faithful f64:3F8FC0A8B0FC03E5, f64:3F8FC0A8B0FC03E6) | numerics/log1p/0006 (revision 6) |
| N1:3213 | - | 3F9FFFFFFFFFFFFF | f64:3F9F829B0E7832FF | f64:3F9F829B0E783300 | f64:3F9F829B0E7832FF (faithful f64:3F9F829B0E7832FF, f64:3F9F829B0E783300) | numerics/log1p/0006 (revision 6) |
| N1:3215 | - | 3FA0000000000001 | f64:3F9F829B0E783302 | f64:3F9F829B0E783300 | f64:3F9F829B0E783302 (faithful f64:3F9F829B0E783302, f64:3F9F829B0E783303) | numerics/log1p/0006 (revision 6) |
| N1:3216 | - | 3FAFFFFFFFFFFFFF | f64:3FAF0A30C01162A5 | f64:3FAF0A30C01162A6 | f64:3FAF0A30C01162A5 (faithful f64:3FAF0A30C01162A5, f64:3FAF0A30C01162A6) | numerics/log1p/0006 (revision 6) |
| N1:3218 | - | 3FB0000000000001 | f64:3FAF0A30C01162A8 | f64:3FAF0A30C01162A6 | f64:3FAF0A30C01162A8 (faithful f64:3FAF0A30C01162A8, f64:3FAF0A30C01162A9) | numerics/log1p/0006 (revision 6) |
| N1:3219 | - | 3FBFFFFFFFFFFFFF | f64:3FBE27076E2AF2E5 | f64:3FBE27076E2AF2E6 | f64:3FBE27076E2AF2E5 (faithful f64:3FBE27076E2AF2E5, f64:3FBE27076E2AF2E6) | numerics/log1p/0006 (revision 6) |
| N1:3221 | - | 3FC0000000000001 | f64:3FBE27076E2AF2E8 | f64:3FBE27076E2AF2E6 | f64:3FBE27076E2AF2E8 (faithful f64:3FBE27076E2AF2E7, f64:3FBE27076E2AF2E8) | numerics/log1p/0006 (revision 6) |
| N1:3222 | - | 3FCFFFFFFFFFFFFF | f64:3FCC8FF7C79A9A21 | f64:3FCC8FF7C79A9A22 | f64:3FCC8FF7C79A9A21 (faithful f64:3FCC8FF7C79A9A20, f64:3FCC8FF7C79A9A21) | numerics/log1p/0006 (revision 6) |
| N1:3224 | - | 3FD0000000000001 | f64:3FCC8FF7C79A9A23 | f64:3FCC8FF7C79A9A22 | f64:3FCC8FF7C79A9A23 (faithful f64:3FCC8FF7C79A9A23, f64:3FCC8FF7C79A9A24) | numerics/log1p/0006 (revision 6) |
| N1:3225 | - | 3FDFFFFFFFFFFFFF | f64:3FD9F323ECBF984B | f64:3FD9F323ECBF984C | f64:3FD9F323ECBF984B (faithful f64:3FD9F323ECBF984B, f64:3FD9F323ECBF984C) | numerics/log1p/0006 (revision 6) |
| N1:3227 | - | 3FE0000000000001 | f64:3FD9F323ECBF984D | f64:3FD9F323ECBF984C | f64:3FD9F323ECBF984D (faithful f64:3FD9F323ECBF984D, f64:3FD9F323ECBF984E) | numerics/log1p/0006 (revision 6) |
| N1:3230 | - | 3FF0000000000001 | f64:3FE62E42FEFA39F0 | f64:3FE62E42FEFA39EF | f64:3FE62E42FEFA39F0 (faithful f64:3FE62E42FEFA39F0, f64:3FE62E42FEFA39F1) | numerics/log1p/0006 (revision 6) |
| N1:3231 | - | 3FFFFFFFFFFFFFFF | f64:3FF193EA7AAD030A | f64:3FF193EA7AAD030B | f64:3FF193EA7AAD030A (faithful f64:3FF193EA7AAD030A, f64:3FF193EA7AAD030B) | numerics/log1p/0006 (revision 6) |
| N1:3232 | - | 4000000000000000 | f64:3FF193EA7AAD030A | f64:3FF193EA7AAD030B | f64:3FF193EA7AAD030B (faithful f64:3FF193EA7AAD030A, f64:3FF193EA7AAD030B) | numerics/log1p/0006 (revision 6) |
| N1:3237 | - | 401FFFFFFFFFFFFF | f64:400193EA7AAD030A | f64:400193EA7AAD030B | f64:400193EA7AAD030A (faithful f64:400193EA7AAD030A, f64:400193EA7AAD030B) | numerics/log1p/0006 (revision 6) |
| N1:3245 | - | 4040000000000001 | f64:400BF8D8F4D5B8D2 | f64:400BF8D8F4D5B8D1 | f64:400BF8D8F4D5B8D1 (faithful f64:400BF8D8F4D5B8D1, f64:400BF8D8F4D5B8D2) | numerics/log1p/0006 (revision 6) |

## Math.log1p / V:JsRealm.MathLogOnePlus / class a / is more than one unit in the last place from the exact value near zero: 518579

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:3 | - | 8000000000000001 | f64:8000000000000001 | f64:0000000000000000 | f64:8000000000000001 (faithful f64:8000000000000001, f64:8000000000000002) |  |
| N1:4 | - | 000FFFFFFFFFFFFF | f64:000FFFFFFFFFFFFF | f64:0000000000000000 | f64:000FFFFFFFFFFFFF (faithful f64:000FFFFFFFFFFFFE, f64:000FFFFFFFFFFFFF) |  |
| N1:5 | - | 800FFFFFFFFFFFFF | f64:800FFFFFFFFFFFFF | f64:0000000000000000 | f64:800FFFFFFFFFFFFF (faithful f64:800FFFFFFFFFFFFF, f64:8010000000000000) |  |
| N1:6 | - | 0010000000000000 | f64:0010000000000000 | f64:0000000000000000 | f64:0010000000000000 (faithful f64:000FFFFFFFFFFFFF, f64:0010000000000000) |  |
| N1:7 | - | 8010000000000000 | f64:8010000000000000 | f64:0000000000000000 | f64:8010000000000000 (faithful f64:8010000000000000, f64:8010000000000001) |  |
| N1:13 | - | 0000000000000002 | f64:0000000000000002 | f64:0000000000000000 | f64:0000000000000002 (faithful f64:0000000000000001, f64:0000000000000002) |  |
| N1:14 | - | 0000000000000003 | f64:0000000000000003 | f64:0000000000000000 | f64:0000000000000003 (faithful f64:0000000000000002, f64:0000000000000003) |  |
| N1:15 | - | 0000000000000004 | f64:0000000000000004 | f64:0000000000000000 | f64:0000000000000004 (faithful f64:0000000000000003, f64:0000000000000004) |  |
| N1:16 | - | 0000000000000005 | f64:0000000000000005 | f64:0000000000000000 | f64:0000000000000005 (faithful f64:0000000000000004, f64:0000000000000005) |  |
| N1:17 | - | 0000000000000007 | f64:0000000000000007 | f64:0000000000000000 | f64:0000000000000007 (faithful f64:0000000000000006, f64:0000000000000007) |  |
| N1:18 | - | 0000000000000008 | f64:0000000000000008 | f64:0000000000000000 | f64:0000000000000008 (faithful f64:0000000000000007, f64:0000000000000008) |  |
| N1:19 | - | 0000000000000009 | f64:0000000000000009 | f64:0000000000000000 | f64:0000000000000009 (faithful f64:0000000000000008, f64:0000000000000009) |  |
| N1:20 | - | 000000000000000F | f64:000000000000000F | f64:0000000000000000 | f64:000000000000000F (faithful f64:000000000000000E, f64:000000000000000F) |  |
| N1:21 | - | 0000000000000010 | f64:0000000000000010 | f64:0000000000000000 | f64:0000000000000010 (faithful f64:000000000000000F, f64:0000000000000010) |  |
| N1:22 | - | 0000000000000011 | f64:0000000000000011 | f64:0000000000000000 | f64:0000000000000011 (faithful f64:0000000000000010, f64:0000000000000011) |  |
| N1:23 | - | 000000000000001F | f64:000000000000001F | f64:0000000000000000 | f64:000000000000001F (faithful f64:000000000000001E, f64:000000000000001F) |  |
| N1:24 | - | 0000000000000020 | f64:0000000000000020 | f64:0000000000000000 | f64:0000000000000020 (faithful f64:000000000000001F, f64:0000000000000020) |  |
| N1:25 | - | 0000000000000021 | f64:0000000000000021 | f64:0000000000000000 | f64:0000000000000021 (faithful f64:0000000000000020, f64:0000000000000021) |  |
| N1:26 | - | 000000000000003F | f64:000000000000003F | f64:0000000000000000 | f64:000000000000003F (faithful f64:000000000000003E, f64:000000000000003F) |  |
| N1:27 | - | 0000000000000040 | f64:0000000000000040 | f64:0000000000000000 | f64:0000000000000040 (faithful f64:000000000000003F, f64:0000000000000040) |  |

## Math.log1p / V:JsRealm.MathLogOnePlus / class b / both admitted: 11866

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:2 | - | 0000000000000001 | f64:0000000000000001 | f64:0000000000000000 | f64:0000000000000001 (faithful f64:0000000000000000, f64:0000000000000001) | numerics/log1p/0006 (revision 6) |
| N1:3072 | - | 3CAFFFFFFFFFFFFF | f64:3CAFFFFFFFFFFFFE | f64:3CAFFFFFFFFFFFFF | f64:3CAFFFFFFFFFFFFE (faithful f64:3CAFFFFFFFFFFFFE, f64:3CAFFFFFFFFFFFFF) | numerics/log1p/0006 (revision 6) |
| N1:3075 | - | 3CBFFFFFFFFFFFFF | f64:3CBFFFFFFFFFFFFD | f64:3CBFFFFFFFFFFFFE | f64:3CBFFFFFFFFFFFFD (faithful f64:3CBFFFFFFFFFFFFD, f64:3CBFFFFFFFFFFFFE) | numerics/log1p/0006 (revision 6) |
| N1:3078 | - | 3CCFFFFFFFFFFFFF | f64:3CCFFFFFFFFFFFFB | f64:3CCFFFFFFFFFFFFC | f64:3CCFFFFFFFFFFFFB (faithful f64:3CCFFFFFFFFFFFFB, f64:3CCFFFFFFFFFFFFC) | numerics/log1p/0006 (revision 6) |
| N1:3081 | - | 3CDFFFFFFFFFFFFF | f64:3CDFFFFFFFFFFFF7 | f64:3CDFFFFFFFFFFFF8 | f64:3CDFFFFFFFFFFFF7 (faithful f64:3CDFFFFFFFFFFFF7, f64:3CDFFFFFFFFFFFF8) | numerics/log1p/0006 (revision 6) |
| N1:3084 | - | 3CEFFFFFFFFFFFFF | f64:3CEFFFFFFFFFFFEF | f64:3CEFFFFFFFFFFFF0 | f64:3CEFFFFFFFFFFFEF (faithful f64:3CEFFFFFFFFFFFEF, f64:3CEFFFFFFFFFFFF0) | numerics/log1p/0006 (revision 6) |
| N1:3087 | - | 3CFFFFFFFFFFFFFF | f64:3CFFFFFFFFFFFFDF | f64:3CFFFFFFFFFFFFE0 | f64:3CFFFFFFFFFFFFDF (faithful f64:3CFFFFFFFFFFFFDF, f64:3CFFFFFFFFFFFFE0) | numerics/log1p/0006 (revision 6) |
| N1:3090 | - | 3D0FFFFFFFFFFFFF | f64:3D0FFFFFFFFFFFBF | f64:3D0FFFFFFFFFFFC0 | f64:3D0FFFFFFFFFFFBF (faithful f64:3D0FFFFFFFFFFFBF, f64:3D0FFFFFFFFFFFC0) | numerics/log1p/0006 (revision 6) |
| N1:3093 | - | 3D1FFFFFFFFFFFFF | f64:3D1FFFFFFFFFFF7F | f64:3D1FFFFFFFFFFF80 | f64:3D1FFFFFFFFFFF7F (faithful f64:3D1FFFFFFFFFFF7F, f64:3D1FFFFFFFFFFF80) | numerics/log1p/0006 (revision 6) |
| N1:3096 | - | 3D2FFFFFFFFFFFFF | f64:3D2FFFFFFFFFFEFF | f64:3D2FFFFFFFFFFF00 | f64:3D2FFFFFFFFFFEFF (faithful f64:3D2FFFFFFFFFFEFF, f64:3D2FFFFFFFFFFF00) | numerics/log1p/0006 (revision 6) |
| N1:3099 | - | 3D3FFFFFFFFFFFFF | f64:3D3FFFFFFFFFFDFF | f64:3D3FFFFFFFFFFE00 | f64:3D3FFFFFFFFFFDFF (faithful f64:3D3FFFFFFFFFFDFF, f64:3D3FFFFFFFFFFE00) | numerics/log1p/0006 (revision 6) |
| N1:3102 | - | 3D4FFFFFFFFFFFFF | f64:3D4FFFFFFFFFFBFF | f64:3D4FFFFFFFFFFC00 | f64:3D4FFFFFFFFFFBFF (faithful f64:3D4FFFFFFFFFFBFF, f64:3D4FFFFFFFFFFC00) | numerics/log1p/0006 (revision 6) |
| N1:3105 | - | 3D5FFFFFFFFFFFFF | f64:3D5FFFFFFFFFF7FF | f64:3D5FFFFFFFFFF800 | f64:3D5FFFFFFFFFF7FF (faithful f64:3D5FFFFFFFFFF7FF, f64:3D5FFFFFFFFFF800) | numerics/log1p/0006 (revision 6) |
| N1:3108 | - | 3D6FFFFFFFFFFFFF | f64:3D6FFFFFFFFFEFFF | f64:3D6FFFFFFFFFF000 | f64:3D6FFFFFFFFFEFFF (faithful f64:3D6FFFFFFFFFEFFF, f64:3D6FFFFFFFFFF000) | numerics/log1p/0006 (revision 6) |
| N1:3111 | - | 3D7FFFFFFFFFFFFF | f64:3D7FFFFFFFFFDFFF | f64:3D7FFFFFFFFFE000 | f64:3D7FFFFFFFFFDFFF (faithful f64:3D7FFFFFFFFFDFFF, f64:3D7FFFFFFFFFE000) | numerics/log1p/0006 (revision 6) |
| N1:3114 | - | 3D8FFFFFFFFFFFFF | f64:3D8FFFFFFFFFBFFF | f64:3D8FFFFFFFFFC000 | f64:3D8FFFFFFFFFBFFF (faithful f64:3D8FFFFFFFFFBFFF, f64:3D8FFFFFFFFFC000) | numerics/log1p/0006 (revision 6) |
| N1:3117 | - | 3D9FFFFFFFFFFFFF | f64:3D9FFFFFFFFF7FFF | f64:3D9FFFFFFFFF8000 | f64:3D9FFFFFFFFF7FFF (faithful f64:3D9FFFFFFFFF7FFF, f64:3D9FFFFFFFFF8000) | numerics/log1p/0006 (revision 6) |
| N1:3120 | - | 3DAFFFFFFFFFFFFF | f64:3DAFFFFFFFFEFFFF | f64:3DAFFFFFFFFF0000 | f64:3DAFFFFFFFFEFFFF (faithful f64:3DAFFFFFFFFEFFFF, f64:3DAFFFFFFFFF0000) | numerics/log1p/0006 (revision 6) |
| N1:3123 | - | 3DBFFFFFFFFFFFFF | f64:3DBFFFFFFFFDFFFF | f64:3DBFFFFFFFFE0000 | f64:3DBFFFFFFFFDFFFF (faithful f64:3DBFFFFFFFFDFFFF, f64:3DBFFFFFFFFE0000) | numerics/log1p/0006 (revision 6) |
| N1:3126 | - | 3DCFFFFFFFFFFFFF | f64:3DCFFFFFFFFBFFFF | f64:3DCFFFFFFFFC0000 | f64:3DCFFFFFFFFBFFFF (faithful f64:3DCFFFFFFFFBFFFF, f64:3DCFFFFFFFFC0000) | numerics/log1p/0006 (revision 6) |

## Math.sumPrecise / V:JsRealm.MathSumPrecise / class a / misses the clause's special case or exact result: 40

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N4:281 | - | 7FEFFFFFFFFFFFFF,FFEFFFFFFFFFFFFF,0000000000000001 | f64:0000000000000001 | f64:0000000000000000 | f64:0000000000000001 |  |
| N4:286 | - | 7FEFFFFFFFFFFFFF,7FEFFFFFFFFFFFFF,FFEFFFFFFFFFFFFF,FFEFFFFFFFFFFFFF,0000000000000001 | f64:0000000000000001 | f64:0000000000000000 | f64:0000000000000001 |  |
| N4:291 | - | 7FEFFFFFFFFFFFFF,7FEFFFFFFFFFFFFF,7FEFFFFFFFFFFFFF,FFEFFFFFFFFFFFFF,FFEFFFFFFFFFFFFF,FFEFFFFFFFFFFFFF,0000000000000001 | f64:0000000000000001 | f64:0000000000000000 | f64:0000000000000001 |  |
| N4:296 | - | 7FEFFFFFFFFFFFFF,7FEFFFFFFFFFFFFF,7FEFFFFFFFFFFFFF,7FEFFFFFFFFFFFFF,FFEFFFFFFFFFFFFF,FFEFFFFFFFFFFFFF,FFEFFFFFFFFFFFFF,F | f64:0000000000000001 | f64:0000000000000000 | f64:0000000000000001 |  |
| N4:298 | - | 7FE1CCF385EBC8A0,0000000000000001,FFE1CCF385EBC8A0 | f64:0000000000000001 | f64:0000000000000000 | f64:0000000000000001 |  |
| N4:299 | - | 7FE1CCF385EBC8A0,FFE1CCF385EBC8A0,0000000000000001 | f64:0000000000000001 | f64:0000000000000000 | f64:0000000000000001 |  |
| N4:300 | - | 0000000000000001,7FE1CCF385EBC8A0,FFE1CCF385EBC8A0 | f64:0000000000000001 | f64:0000000000000000 | f64:0000000000000001 |  |
| N4:301 | - | 0000000000000001,FFE1CCF385EBC8A0,7FE1CCF385EBC8A0 | f64:0000000000000001 | f64:0000000000000000 | f64:0000000000000001 |  |
| N4:302 | - | FFE1CCF385EBC8A0,7FE1CCF385EBC8A0,0000000000000001 | f64:0000000000000001 | f64:0000000000000000 | f64:0000000000000001 |  |
| N4:303 | - | FFE1CCF385EBC8A0,0000000000000001,7FE1CCF385EBC8A0 | f64:0000000000000001 | f64:0000000000000000 | f64:0000000000000001 |  |
| N4:304 | - | 7FE1CCF385EBC8A0,0010000000000000,FFE1CCF385EBC8A0 | f64:0010000000000000 | f64:0000000000000000 | f64:0010000000000000 |  |
| N4:305 | - | 7FE1CCF385EBC8A0,FFE1CCF385EBC8A0,0010000000000000 | f64:0010000000000000 | f64:0000000000000000 | f64:0010000000000000 |  |
| N4:306 | - | 0010000000000000,7FE1CCF385EBC8A0,FFE1CCF385EBC8A0 | f64:0010000000000000 | f64:0000000000000000 | f64:0010000000000000 |  |
| N4:307 | - | 0010000000000000,FFE1CCF385EBC8A0,7FE1CCF385EBC8A0 | f64:0010000000000000 | f64:0000000000000000 | f64:0010000000000000 |  |
| N4:308 | - | FFE1CCF385EBC8A0,7FE1CCF385EBC8A0,0010000000000000 | f64:0010000000000000 | f64:0000000000000000 | f64:0010000000000000 |  |
| N4:309 | - | FFE1CCF385EBC8A0,0010000000000000,7FE1CCF385EBC8A0 | f64:0010000000000000 | f64:0000000000000000 | f64:0010000000000000 |  |
| N4:310 | - | 7FE1CCF385EBC8A0,01A56E1FC2F8F359,FFE1CCF385EBC8A0 | f64:01A56E1FC2F8F359 | f64:0000000000000000 | f64:01A56E1FC2F8F359 |  |
| N4:311 | - | 7FE1CCF385EBC8A0,FFE1CCF385EBC8A0,01A56E1FC2F8F359 | f64:01A56E1FC2F8F359 | f64:0000000000000000 | f64:01A56E1FC2F8F359 |  |
| N4:312 | - | 01A56E1FC2F8F359,7FE1CCF385EBC8A0,FFE1CCF385EBC8A0 | f64:01A56E1FC2F8F359 | f64:0000000000000000 | f64:01A56E1FC2F8F359 |  |
| N4:313 | - | 01A56E1FC2F8F359,FFE1CCF385EBC8A0,7FE1CCF385EBC8A0 | f64:01A56E1FC2F8F359 | f64:0000000000000000 | f64:01A56E1FC2F8F359 |  |

## Number::exponentiate / J:JSValue.Power / class a / is outside the admitted bound: 1

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N3P:56 | - | 3FF0000000000000,7FF8000000000000 | NaN | f64:3FF0000000000000 | NaN |  |

## StringToBigInt / V:JsBigInt.TryParseStringInteger / class unclassified / the reference cannot judge the input: 1062

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| B1V:24615 | len:315661:sha256:41cee415cb60ec71241f9c5165705bf64fe4d6f8bde52f1a296aa5aefa31d8 | len:262145:sha256:d44fffc44f5eab4d10ba0f6e0f889b306a0562c168ada297e5d3af7ab7de8ed2 | error:RangeError:1\|charge:18685422 | exception:NullReferenceException | (reference failed: ValueError) |  |
| B1V:24615 | len:315665:sha256:3c4b8aa83a5ac3f6a0be1a89dcc36c8b310500e30ea0743a84d982d18933f9 | len:262145:sha256:d44fffc44f5eab4d10ba0f6e0f889b306a0562c168ada297e5d3af7ab7de8ed2 | error:RangeError:1\|charge:18685422 | exception:NullReferenceException | (reference failed: ValueError) |  |
| B1V:24615 | len:315665:sha256:840a736a474cb96e387d1fd6a5fc0a0b6f901e76c94bfdcea291bce9524d3c | len:262145:sha256:d44fffc44f5eab4d10ba0f6e0f889b306a0562c168ada297e5d3af7ab7de8ed2 | error:RangeError:1\|charge:18685422 | exception:NullReferenceException | (reference failed: ValueError) |  |
| B1V:24615 | len:315665:sha256:4b0a6c7bdbdce387762304415202e7498ee0cd18081d6e127cff0a38c76b13 | len:262145:sha256:d44fffc44f5eab4d10ba0f6e0f889b306a0562c168ada297e5d3af7ab7de8ed2 | error:RangeError:1\|charge:18685422 | exception:NullReferenceException | (reference failed: ValueError) |  |
| B1V:24615 | len:315665:sha256:f9aa74c8894231feb243693d584e025baa50e28f6ef6ec0594f3da7d5b0b85 | len:262145:sha256:d44fffc44f5eab4d10ba0f6e0f889b306a0562c168ada297e5d3af7ab7de8ed2 | error:RangeError:1\|charge:18685422 | exception:NullReferenceException | (reference failed: ValueError) |  |
| B1V:24615 | len:315665:sha256:af74aea6114d148d0b37c7bb0a9e169b38933c126772d51cda9cb1cf5f0115 | len:262145:sha256:d44fffc44f5eab4d10ba0f6e0f889b306a0562c168ada297e5d3af7ab7de8ed2 | error:RangeError:1\|charge:18685422 | exception:NullReferenceException | (reference failed: ValueError) |  |
| B1V:24615 | len:315665:sha256:5d9eeae66cd49257a03d11c5a1f3870d90e4dd2e2d0ae425232511d865acbf | len:262145:sha256:d44fffc44f5eab4d10ba0f6e0f889b306a0562c168ada297e5d3af7ab7de8ed2 | error:RangeError:1\|charge:18685422 | exception:NullReferenceException | (reference failed: ValueError) |  |
| B1V:24615 | len:315665:sha256:8afeadbe9bb062207123cbf61958b6ea4ec65520f8121600d5b4df148f8917 | len:262145:sha256:d44fffc44f5eab4d10ba0f6e0f889b306a0562c168ada297e5d3af7ab7de8ed2 | error:RangeError:1\|charge:18685422 | exception:NullReferenceException | (reference failed: ValueError) |  |
| B1V:24615 | len:315665:sha256:1b2de29317ed5e26bd8760f8b3040a1e869fa6a298877c6d0e82b43060f730 | len:262145:sha256:d44fffc44f5eab4d10ba0f6e0f889b306a0562c168ada297e5d3af7ab7de8ed2 | error:RangeError:1\|charge:18685422 | exception:NullReferenceException | (reference failed: ValueError) |  |
| B1V:24615 | len:315665:sha256:85b3c2da74c7e24b20026b8b07a1cfa86d5a151f704d3b9e395df743ee5144 | len:262145:sha256:d44fffc44f5eab4d10ba0f6e0f889b306a0562c168ada297e5d3af7ab7de8ed2 | error:RangeError:1\|charge:18685422 | exception:NullReferenceException | (reference failed: ValueError) |  |
| B1V:24615 | len:315665:sha256:5c4b97cf5535912e96b391f3392a9bf997aa3447e68e1187fdd19efbb21a7f | len:262145:sha256:d44fffc44f5eab4d10ba0f6e0f889b306a0562c168ada297e5d3af7ab7de8ed2 | error:RangeError:1\|charge:18685422 | exception:NullReferenceException | (reference failed: ValueError) |  |
| B1V:24615 | len:315665:sha256:adebebea961bacc26627c56dc922e9762b7f8cb05e356afcb1d5fa580c64df | len:262145:sha256:d44fffc44f5eab4d10ba0f6e0f889b306a0562c168ada297e5d3af7ab7de8ed2 | error:RangeError:1\|charge:18685422 | exception:NullReferenceException | (reference failed: ValueError) |  |
| B1V:24615 | len:315665:sha256:065359c8a8ab18475499e83713b9cb41b1a60a193c695c24e9cfb891e36140 | len:262145:sha256:d44fffc44f5eab4d10ba0f6e0f889b306a0562c168ada297e5d3af7ab7de8ed2 | error:RangeError:1\|charge:18685422 | exception:NullReferenceException | (reference failed: ValueError) |  |
| B1V:24615 | len:315665:sha256:827511ed851177a031aa71a1b28516fa41973afc20af10c0b7a66d6a3a285d | len:262145:sha256:d44fffc44f5eab4d10ba0f6e0f889b306a0562c168ada297e5d3af7ab7de8ed2 | error:RangeError:1\|charge:18685422 | exception:NullReferenceException | (reference failed: ValueError) |  |
| B1V:24615 | len:315665:sha256:c9f4366c6a2b16f298add9a7dfb2630dba9111ce6fc3b2dd06c897e3db32f1 | len:262145:sha256:d44fffc44f5eab4d10ba0f6e0f889b306a0562c168ada297e5d3af7ab7de8ed2 | error:RangeError:1\|charge:18685422 | exception:NullReferenceException | (reference failed: ValueError) |  |
| B1V:24615 | len:315665:sha256:e42059167e45a5864168ba8a5eb1aab52e136b9fc49263d46b60cf2fa5e080 | len:262145:sha256:d44fffc44f5eab4d10ba0f6e0f889b306a0562c168ada297e5d3af7ab7de8ed2 | error:RangeError:1\|charge:18685422 | exception:NullReferenceException | (reference failed: ValueError) |  |
| B1V:24615 | len:315665:sha256:487d272a3d726ed1ed0bc3c01915f63059a078f6de1578cbad4741c86f3069 | len:262145:sha256:d44fffc44f5eab4d10ba0f6e0f889b306a0562c168ada297e5d3af7ab7de8ed2 | error:RangeError:1\|charge:18685422 | exception:NullReferenceException | (reference failed: ValueError) |  |
| B1V:24615 | len:315665:sha256:707b37ec534104d444423b7330c6277dc0a7bead3c571d025f37a9eb235761 | len:262145:sha256:d44fffc44f5eab4d10ba0f6e0f889b306a0562c168ada297e5d3af7ab7de8ed2 | error:RangeError:1\|charge:18685422 | exception:NullReferenceException | (reference failed: ValueError) |  |
| B1V:24615 | len:315665:sha256:1a27bb351c6a85238385fd28780805a3210539310370b400f251766ff542ce | len:262145:sha256:d44fffc44f5eab4d10ba0f6e0f889b306a0562c168ada297e5d3af7ab7de8ed2 | error:RangeError:1\|charge:18685422 | exception:NullReferenceException | (reference failed: ValueError) |  |
| B1V:24615 | len:315665:sha256:e3652c65a059e967bb2af5b51340aef175dba4ac15f542b2d9bd2717975a87 | len:262145:sha256:d44fffc44f5eab4d10ba0f6e0f889b306a0562c168ada297e5d3af7ab7de8ed2 | error:RangeError:1\|charge:18685422 | exception:NullReferenceException | (reference failed: ValueError) |  |

## ToIndex / J:DataView.ToByteOffset / class a / saturates at its type's bound: 5808

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:3322 | - | 41E0000000000000 | num:2147483648 | num:2147483647 | num:2147483648 |  |
| N1:3323 | - | 41E0000000000001 | num:2147483648 | num:2147483647 | num:2147483648 |  |
| N1:3324 | - | 41EFFFFFFFFFFFFF | num:4294967295 | num:2147483647 | num:4294967295 |  |
| N1:3325 | - | 41F0000000000000 | num:4294967296 | num:2147483647 | num:4294967296 |  |
| N1:3326 | - | 41F0000000000001 | num:4294967296 | num:2147483647 | num:4294967296 |  |
| N1:3327 | - | 41FFFFFFFFFFFFFF | num:8589934591 | num:2147483647 | num:8589934591 |  |
| N1:3328 | - | 4200000000000000 | num:8589934592 | num:2147483647 | num:8589934592 |  |
| N1:3329 | - | 4200000000000001 | num:8589934592 | num:2147483647 | num:8589934592 |  |
| N1:3330 | - | 420FFFFFFFFFFFFF | num:17179869183 | num:2147483647 | num:17179869183 |  |
| N1:3331 | - | 4210000000000000 | num:17179869184 | num:2147483647 | num:17179869184 |  |
| N1:3332 | - | 4210000000000001 | num:17179869184 | num:2147483647 | num:17179869184 |  |
| N1:3333 | - | 421FFFFFFFFFFFFF | num:34359738367 | num:2147483647 | num:34359738367 |  |
| N1:3334 | - | 4220000000000000 | num:34359738368 | num:2147483647 | num:34359738368 |  |
| N1:3335 | - | 4220000000000001 | num:34359738368 | num:2147483647 | num:34359738368 |  |
| N1:3336 | - | 422FFFFFFFFFFFFF | num:68719476735 | num:2147483647 | num:68719476735 |  |
| N1:3337 | - | 4230000000000000 | num:68719476736 | num:2147483647 | num:68719476736 |  |
| N1:3338 | - | 4230000000000001 | num:68719476736 | num:2147483647 | num:68719476736 |  |
| N1:3339 | - | 423FFFFFFFFFFFFF | num:137438953471 | num:2147483647 | num:137438953471 |  |
| N1:3340 | - | 4240000000000000 | num:137438953472 | num:2147483647 | num:137438953472 |  |
| N1:3341 | - | 4240000000000001 | num:137438953472 | num:2147483647 | num:137438953472 |  |

## ToIndex / J:JSArrayBuffer.ToBufferLength / class a / refuses with a RangeError an input the clause answers: 5808

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:3322 | - | 41E0000000000000 | num:2147483648 | error:RangeError | num:2147483648 |  |
| N1:3323 | - | 41E0000000000001 | num:2147483648 | error:RangeError | num:2147483648 |  |
| N1:3324 | - | 41EFFFFFFFFFFFFF | num:4294967295 | error:RangeError | num:4294967295 |  |
| N1:3325 | - | 41F0000000000000 | num:4294967296 | error:RangeError | num:4294967296 |  |
| N1:3326 | - | 41F0000000000001 | num:4294967296 | error:RangeError | num:4294967296 |  |
| N1:3327 | - | 41FFFFFFFFFFFFFF | num:8589934591 | error:RangeError | num:8589934591 |  |
| N1:3328 | - | 4200000000000000 | num:8589934592 | error:RangeError | num:8589934592 |  |
| N1:3329 | - | 4200000000000001 | num:8589934592 | error:RangeError | num:8589934592 |  |
| N1:3330 | - | 420FFFFFFFFFFFFF | num:17179869183 | error:RangeError | num:17179869183 |  |
| N1:3331 | - | 4210000000000000 | num:17179869184 | error:RangeError | num:17179869184 |  |
| N1:3332 | - | 4210000000000001 | num:17179869184 | error:RangeError | num:17179869184 |  |
| N1:3333 | - | 421FFFFFFFFFFFFF | num:34359738367 | error:RangeError | num:34359738367 |  |
| N1:3334 | - | 4220000000000000 | num:34359738368 | error:RangeError | num:34359738368 |  |
| N1:3335 | - | 4220000000000001 | num:34359738368 | error:RangeError | num:34359738368 |  |
| N1:3336 | - | 422FFFFFFFFFFFFF | num:68719476735 | error:RangeError | num:68719476735 |  |
| N1:3337 | - | 4230000000000000 | num:68719476736 | error:RangeError | num:68719476736 |  |
| N1:3338 | - | 4230000000000001 | num:68719476736 | error:RangeError | num:68719476736 |  |
| N1:3339 | - | 423FFFFFFFFFFFFF | num:137438953471 | error:RangeError | num:137438953471 |  |
| N1:3340 | - | 4240000000000000 | num:137438953472 | error:RangeError | num:137438953472 |  |
| N1:3341 | - | 4240000000000001 | num:137438953472 | error:RangeError | num:137438953472 |  |

## ToIndex / J:JSAtomics.ToIndex / class a / refuses with a RangeError an input the clause answers: 5808

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:3322 | - | 41E0000000000000 | num:2147483648 | error:RangeError | num:2147483648 |  |
| N1:3323 | - | 41E0000000000001 | num:2147483648 | error:RangeError | num:2147483648 |  |
| N1:3324 | - | 41EFFFFFFFFFFFFF | num:4294967295 | error:RangeError | num:4294967295 |  |
| N1:3325 | - | 41F0000000000000 | num:4294967296 | error:RangeError | num:4294967296 |  |
| N1:3326 | - | 41F0000000000001 | num:4294967296 | error:RangeError | num:4294967296 |  |
| N1:3327 | - | 41FFFFFFFFFFFFFF | num:8589934591 | error:RangeError | num:8589934591 |  |
| N1:3328 | - | 4200000000000000 | num:8589934592 | error:RangeError | num:8589934592 |  |
| N1:3329 | - | 4200000000000001 | num:8589934592 | error:RangeError | num:8589934592 |  |
| N1:3330 | - | 420FFFFFFFFFFFFF | num:17179869183 | error:RangeError | num:17179869183 |  |
| N1:3331 | - | 4210000000000000 | num:17179869184 | error:RangeError | num:17179869184 |  |
| N1:3332 | - | 4210000000000001 | num:17179869184 | error:RangeError | num:17179869184 |  |
| N1:3333 | - | 421FFFFFFFFFFFFF | num:34359738367 | error:RangeError | num:34359738367 |  |
| N1:3334 | - | 4220000000000000 | num:34359738368 | error:RangeError | num:34359738368 |  |
| N1:3335 | - | 4220000000000001 | num:34359738368 | error:RangeError | num:34359738368 |  |
| N1:3336 | - | 422FFFFFFFFFFFFF | num:68719476735 | error:RangeError | num:68719476735 |  |
| N1:3337 | - | 4230000000000000 | num:68719476736 | error:RangeError | num:68719476736 |  |
| N1:3338 | - | 4230000000000001 | num:68719476736 | error:RangeError | num:68719476736 |  |
| N1:3339 | - | 423FFFFFFFFFFFFF | num:137438953471 | error:RangeError | num:137438953471 |  |
| N1:3340 | - | 4240000000000000 | num:137438953472 | error:RangeError | num:137438953472 |  |
| N1:3341 | - | 4240000000000001 | num:137438953472 | error:RangeError | num:137438953472 |  |

## ToIndex / J:TypedArrayParameters.ToTypedArrayLength / class a / refuses with a RangeError an input the clause answers: 5808

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:3322 | - | 41E0000000000000 | num:2147483648 | error:RangeError | num:2147483648 |  |
| N1:3323 | - | 41E0000000000001 | num:2147483648 | error:RangeError | num:2147483648 |  |
| N1:3324 | - | 41EFFFFFFFFFFFFF | num:4294967295 | error:RangeError | num:4294967295 |  |
| N1:3325 | - | 41F0000000000000 | num:4294967296 | error:RangeError | num:4294967296 |  |
| N1:3326 | - | 41F0000000000001 | num:4294967296 | error:RangeError | num:4294967296 |  |
| N1:3327 | - | 41FFFFFFFFFFFFFF | num:8589934591 | error:RangeError | num:8589934591 |  |
| N1:3328 | - | 4200000000000000 | num:8589934592 | error:RangeError | num:8589934592 |  |
| N1:3329 | - | 4200000000000001 | num:8589934592 | error:RangeError | num:8589934592 |  |
| N1:3330 | - | 420FFFFFFFFFFFFF | num:17179869183 | error:RangeError | num:17179869183 |  |
| N1:3331 | - | 4210000000000000 | num:17179869184 | error:RangeError | num:17179869184 |  |
| N1:3332 | - | 4210000000000001 | num:17179869184 | error:RangeError | num:17179869184 |  |
| N1:3333 | - | 421FFFFFFFFFFFFF | num:34359738367 | error:RangeError | num:34359738367 |  |
| N1:3334 | - | 4220000000000000 | num:34359738368 | error:RangeError | num:34359738368 |  |
| N1:3335 | - | 4220000000000001 | num:34359738368 | error:RangeError | num:34359738368 |  |
| N1:3336 | - | 422FFFFFFFFFFFFF | num:68719476735 | error:RangeError | num:68719476735 |  |
| N1:3337 | - | 4230000000000000 | num:68719476736 | error:RangeError | num:68719476736 |  |
| N1:3338 | - | 4230000000000001 | num:68719476736 | error:RangeError | num:68719476736 |  |
| N1:3339 | - | 423FFFFFFFFFFFFF | num:137438953471 | error:RangeError | num:137438953471 |  |
| N1:3340 | - | 4240000000000000 | num:137438953472 | error:RangeError | num:137438953472 |  |
| N1:3341 | - | 4240000000000001 | num:137438953472 | error:RangeError | num:137438953472 |  |

## ToInt16 / J:JSAtomics.TruncateToElement(Int16, ToIntegerOperand) / class a / wraps the operand after saturating it to 64 bits, not the integer itself: 250486

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:8 | - | 7FEFFFFFFFFFFFFF | int:0 | int:-1 | int:0 |  |
| N1:3418 | - | 43E0000000000000 | int:0 | int:-1 | int:0 |  |
| N1:3419 | - | 43E0000000000001 | int:2048 | int:-1 | int:2048 |  |
| N1:3420 | - | 43EFFFFFFFFFFFFF | int:-2048 | int:-1 | int:-2048 |  |
| N1:3421 | - | 43F0000000000000 | int:0 | int:-1 | int:0 |  |
| N1:3422 | - | 43F0000000000001 | int:4096 | int:-1 | int:4096 |  |
| N1:3423 | - | 43FFFFFFFFFFFFFF | int:-4096 | int:-1 | int:-4096 |  |
| N1:3424 | - | 4400000000000000 | int:0 | int:-1 | int:0 |  |
| N1:3425 | - | 4400000000000001 | int:8192 | int:-1 | int:8192 |  |
| N1:3426 | - | 440FFFFFFFFFFFFF | int:-8192 | int:-1 | int:-8192 |  |
| N1:3427 | - | 4410000000000000 | int:0 | int:-1 | int:0 |  |
| N1:3428 | - | 4410000000000001 | int:16384 | int:-1 | int:16384 |  |
| N1:3429 | - | 441FFFFFFFFFFFFF | int:-16384 | int:-1 | int:-16384 |  |
| N1:3430 | - | 4420000000000000 | int:0 | int:-1 | int:0 |  |
| N1:3431 | - | 4420000000000001 | int:-32768 | int:-1 | int:-32768 |  |
| N1:3432 | - | 442FFFFFFFFFFFFF | int:-32768 | int:-1 | int:-32768 |  |
| N1:3433 | - | 4430000000000000 | int:0 | int:-1 | int:0 |  |
| N1:3434 | - | 4430000000000001 | int:0 | int:-1 | int:0 |  |
| N1:3435 | - | 443FFFFFFFFFFFFF | int:0 | int:-1 | int:0 |  |
| N1:3436 | - | 4440000000000000 | int:0 | int:-1 | int:0 |  |

## ToInt32 / J:JSAtomics.TruncateToElement(Int32, ToIntegerOperand) / class a / wraps the operand after saturating it to 64 bits, not the integer itself: 254518

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:8 | - | 7FEFFFFFFFFFFFFF | int:0 | int:-1 | int:0 |  |
| N1:3418 | - | 43E0000000000000 | int:0 | int:-1 | int:0 |  |
| N1:3419 | - | 43E0000000000001 | int:2048 | int:-1 | int:2048 |  |
| N1:3420 | - | 43EFFFFFFFFFFFFF | int:-2048 | int:-1 | int:-2048 |  |
| N1:3421 | - | 43F0000000000000 | int:0 | int:-1 | int:0 |  |
| N1:3422 | - | 43F0000000000001 | int:4096 | int:-1 | int:4096 |  |
| N1:3423 | - | 43FFFFFFFFFFFFFF | int:-4096 | int:-1 | int:-4096 |  |
| N1:3424 | - | 4400000000000000 | int:0 | int:-1 | int:0 |  |
| N1:3425 | - | 4400000000000001 | int:8192 | int:-1 | int:8192 |  |
| N1:3426 | - | 440FFFFFFFFFFFFF | int:-8192 | int:-1 | int:-8192 |  |
| N1:3427 | - | 4410000000000000 | int:0 | int:-1 | int:0 |  |
| N1:3428 | - | 4410000000000001 | int:16384 | int:-1 | int:16384 |  |
| N1:3429 | - | 441FFFFFFFFFFFFF | int:-16384 | int:-1 | int:-16384 |  |
| N1:3430 | - | 4420000000000000 | int:0 | int:-1 | int:0 |  |
| N1:3431 | - | 4420000000000001 | int:32768 | int:-1 | int:32768 |  |
| N1:3432 | - | 442FFFFFFFFFFFFF | int:-32768 | int:-1 | int:-32768 |  |
| N1:3433 | - | 4430000000000000 | int:0 | int:-1 | int:0 |  |
| N1:3434 | - | 4430000000000001 | int:65536 | int:-1 | int:65536 |  |
| N1:3435 | - | 443FFFFFFFFFFFFF | int:-65536 | int:-1 | int:-65536 |  |
| N1:3436 | - | 4440000000000000 | int:0 | int:-1 | int:0 |  |

## ToInt8 / J:JSAtomics.TruncateToElement(Int8, ToIntegerOperand) / class a / wraps the operand after saturating it to 64 bits, not the integer itself: 249454

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:8 | - | 7FEFFFFFFFFFFFFF | int:0 | int:-1 | int:0 |  |
| N1:3418 | - | 43E0000000000000 | int:0 | int:-1 | int:0 |  |
| N1:3419 | - | 43E0000000000001 | int:0 | int:-1 | int:0 |  |
| N1:3420 | - | 43EFFFFFFFFFFFFF | int:0 | int:-1 | int:0 |  |
| N1:3421 | - | 43F0000000000000 | int:0 | int:-1 | int:0 |  |
| N1:3422 | - | 43F0000000000001 | int:0 | int:-1 | int:0 |  |
| N1:3423 | - | 43FFFFFFFFFFFFFF | int:0 | int:-1 | int:0 |  |
| N1:3424 | - | 4400000000000000 | int:0 | int:-1 | int:0 |  |
| N1:3425 | - | 4400000000000001 | int:0 | int:-1 | int:0 |  |
| N1:3426 | - | 440FFFFFFFFFFFFF | int:0 | int:-1 | int:0 |  |
| N1:3427 | - | 4410000000000000 | int:0 | int:-1 | int:0 |  |
| N1:3428 | - | 4410000000000001 | int:0 | int:-1 | int:0 |  |
| N1:3429 | - | 441FFFFFFFFFFFFF | int:0 | int:-1 | int:0 |  |
| N1:3430 | - | 4420000000000000 | int:0 | int:-1 | int:0 |  |
| N1:3431 | - | 4420000000000001 | int:0 | int:-1 | int:0 |  |
| N1:3432 | - | 442FFFFFFFFFFFFF | int:0 | int:-1 | int:0 |  |
| N1:3433 | - | 4430000000000000 | int:0 | int:-1 | int:0 |  |
| N1:3434 | - | 4430000000000001 | int:0 | int:-1 | int:0 |  |
| N1:3435 | - | 443FFFFFFFFFFFFF | int:0 | int:-1 | int:0 |  |
| N1:3436 | - | 4440000000000000 | int:0 | int:-1 | int:0 |  |

## ToIntegerOrInfinity / J:JSArrayBuffer.ToIntegerOrInfinity / class a / answers a finite value for an infinity: 2

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:10 | - | 7FF0000000000000 | num:+Infinity | num:2147483647 | num:+Infinity |  |
| N1:11 | - | FFF0000000000000 | num:-Infinity | num:-2147483648 | num:-Infinity |  |

## ToIntegerOrInfinity / J:JSArrayBuffer.ToIntegerOrInfinity / class a / saturates at its type's bound: 512289

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:8 | - | 7FEFFFFFFFFFFFFF | (313 characters) | num:2147483647 | (313 characters) |  |
| N1:9 | - | FFEFFFFFFFFFFFFF | (314 characters) | num:-2147483648 | (314 characters) |  |
| N1:3322 | - | 41E0000000000000 | num:2147483648 | num:2147483647 | num:2147483648 |  |
| N1:3323 | - | 41E0000000000001 | num:2147483648 | num:2147483647 | num:2147483648 |  |
| N1:3324 | - | 41EFFFFFFFFFFFFF | num:4294967295 | num:2147483647 | num:4294967295 |  |
| N1:3325 | - | 41F0000000000000 | num:4294967296 | num:2147483647 | num:4294967296 |  |
| N1:3326 | - | 41F0000000000001 | num:4294967296 | num:2147483647 | num:4294967296 |  |
| N1:3327 | - | 41FFFFFFFFFFFFFF | num:8589934591 | num:2147483647 | num:8589934591 |  |
| N1:3328 | - | 4200000000000000 | num:8589934592 | num:2147483647 | num:8589934592 |  |
| N1:3329 | - | 4200000000000001 | num:8589934592 | num:2147483647 | num:8589934592 |  |
| N1:3330 | - | 420FFFFFFFFFFFFF | num:17179869183 | num:2147483647 | num:17179869183 |  |
| N1:3331 | - | 4210000000000000 | num:17179869184 | num:2147483647 | num:17179869184 |  |
| N1:3332 | - | 4210000000000001 | num:17179869184 | num:2147483647 | num:17179869184 |  |
| N1:3333 | - | 421FFFFFFFFFFFFF | num:34359738367 | num:2147483647 | num:34359738367 |  |
| N1:3334 | - | 4220000000000000 | num:34359738368 | num:2147483647 | num:34359738368 |  |
| N1:3335 | - | 4220000000000001 | num:34359738368 | num:2147483647 | num:34359738368 |  |
| N1:3336 | - | 422FFFFFFFFFFFFF | num:68719476735 | num:2147483647 | num:68719476735 |  |
| N1:3337 | - | 4230000000000000 | num:68719476736 | num:2147483647 | num:68719476736 |  |
| N1:3338 | - | 4230000000000001 | num:68719476736 | num:2147483647 | num:68719476736 |  |
| N1:3339 | - | 423FFFFFFFFFFFFF | num:137438953471 | num:2147483647 | num:137438953471 |  |

## ToIntegerOrInfinity / J:JSArrayPrototype.ToIntegerOrInfinity / class a / answers an infinity for a finite integer (its saturation sentinel): 495484

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:8 | - | 7FEFFFFFFFFFFFFF | (313 characters) | num:+Infinity | (313 characters) |  |
| N1:9 | - | FFEFFFFFFFFFFFFF | (314 characters) | num:-Infinity | (314 characters) |  |
| N1:3418 | - | 43E0000000000000 | num:9223372036854775808 | num:+Infinity | num:9223372036854775808 |  |
| N1:3419 | - | 43E0000000000001 | num:9223372036854777856 | num:+Infinity | num:9223372036854777856 |  |
| N1:3420 | - | 43EFFFFFFFFFFFFF | num:18446744073709549568 | num:+Infinity | num:18446744073709549568 |  |
| N1:3421 | - | 43F0000000000000 | num:18446744073709551616 | num:+Infinity | num:18446744073709551616 |  |
| N1:3422 | - | 43F0000000000001 | num:18446744073709555712 | num:+Infinity | num:18446744073709555712 |  |
| N1:3423 | - | 43FFFFFFFFFFFFFF | num:36893488147419099136 | num:+Infinity | num:36893488147419099136 |  |
| N1:3424 | - | 4400000000000000 | num:36893488147419103232 | num:+Infinity | num:36893488147419103232 |  |
| N1:3425 | - | 4400000000000001 | num:36893488147419111424 | num:+Infinity | num:36893488147419111424 |  |
| N1:3426 | - | 440FFFFFFFFFFFFF | num:73786976294838198272 | num:+Infinity | num:73786976294838198272 |  |
| N1:3427 | - | 4410000000000000 | num:73786976294838206464 | num:+Infinity | num:73786976294838206464 |  |
| N1:3428 | - | 4410000000000001 | num:73786976294838222848 | num:+Infinity | num:73786976294838222848 |  |
| N1:3429 | - | 441FFFFFFFFFFFFF | num:147573952589676396544 | num:+Infinity | num:147573952589676396544 |  |
| N1:3430 | - | 4420000000000000 | num:147573952589676412928 | num:+Infinity | num:147573952589676412928 |  |
| N1:3431 | - | 4420000000000001 | num:147573952589676445696 | num:+Infinity | num:147573952589676445696 |  |
| N1:3432 | - | 442FFFFFFFFFFFFF | num:295147905179352793088 | num:+Infinity | num:295147905179352793088 |  |
| N1:3433 | - | 4430000000000000 | num:295147905179352825856 | num:+Infinity | num:295147905179352825856 |  |
| N1:3434 | - | 4430000000000001 | num:295147905179352891392 | num:+Infinity | num:295147905179352891392 |  |
| N1:3435 | - | 443FFFFFFFFFFFFF | num:590295810358705586176 | num:+Infinity | num:590295810358705586176 |  |

## ToIntegerOrInfinity / J:JSAtomics.ToIntegerOperand / class a / answers a finite value for an infinity: 2

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:10 | - | 7FF0000000000000 | num:+Infinity | num:0 | num:+Infinity |  |
| N1:11 | - | FFF0000000000000 | num:-Infinity | num:0 | num:-Infinity |  |

## ToIntegerOrInfinity / J:JSAtomics.ToIntegerOperand / class a / saturates at its type's bound: 495483

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:8 | - | 7FEFFFFFFFFFFFFF | (313 characters) | num:9223372036854775807 | (313 characters) |  |
| N1:9 | - | FFEFFFFFFFFFFFFF | (314 characters) | num:-9223372036854775808 | (314 characters) |  |
| N1:3418 | - | 43E0000000000000 | num:9223372036854775808 | num:9223372036854775807 | num:9223372036854775808 |  |
| N1:3419 | - | 43E0000000000001 | num:9223372036854777856 | num:9223372036854775807 | num:9223372036854777856 |  |
| N1:3420 | - | 43EFFFFFFFFFFFFF | num:18446744073709549568 | num:9223372036854775807 | num:18446744073709549568 |  |
| N1:3421 | - | 43F0000000000000 | num:18446744073709551616 | num:9223372036854775807 | num:18446744073709551616 |  |
| N1:3422 | - | 43F0000000000001 | num:18446744073709555712 | num:9223372036854775807 | num:18446744073709555712 |  |
| N1:3423 | - | 43FFFFFFFFFFFFFF | num:36893488147419099136 | num:9223372036854775807 | num:36893488147419099136 |  |
| N1:3424 | - | 4400000000000000 | num:36893488147419103232 | num:9223372036854775807 | num:36893488147419103232 |  |
| N1:3425 | - | 4400000000000001 | num:36893488147419111424 | num:9223372036854775807 | num:36893488147419111424 |  |
| N1:3426 | - | 440FFFFFFFFFFFFF | num:73786976294838198272 | num:9223372036854775807 | num:73786976294838198272 |  |
| N1:3427 | - | 4410000000000000 | num:73786976294838206464 | num:9223372036854775807 | num:73786976294838206464 |  |
| N1:3428 | - | 4410000000000001 | num:73786976294838222848 | num:9223372036854775807 | num:73786976294838222848 |  |
| N1:3429 | - | 441FFFFFFFFFFFFF | num:147573952589676396544 | num:9223372036854775807 | num:147573952589676396544 |  |
| N1:3430 | - | 4420000000000000 | num:147573952589676412928 | num:9223372036854775807 | num:147573952589676412928 |  |
| N1:3431 | - | 4420000000000001 | num:147573952589676445696 | num:9223372036854775807 | num:147573952589676445696 |  |
| N1:3432 | - | 442FFFFFFFFFFFFF | num:295147905179352793088 | num:9223372036854775807 | num:295147905179352793088 |  |
| N1:3433 | - | 4430000000000000 | num:295147905179352825856 | num:9223372036854775807 | num:295147905179352825856 |  |
| N1:3434 | - | 4430000000000001 | num:295147905179352891392 | num:9223372036854775807 | num:295147905179352891392 |  |
| N1:3435 | - | 443FFFFFFFFFFFFF | num:590295810358705586176 | num:9223372036854775807 | num:590295810358705586176 |  |

## ToIntegerOrInfinity / J:JSIntlSegments.ContainingPrototype's index / class a / answers -0 where the clause's integer is 0: 260990

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:1 | - | 8000000000000000 | num:0 | num:-0 | num:0 |  |
| N1:3 | - | 8000000000000001 | num:0 | num:-0 | num:0 |  |
| N1:5 | - | 800FFFFFFFFFFFFF | num:0 | num:-0 | num:0 |  |
| N1:7 | - | 8010000000000000 | num:0 | num:-0 | num:0 |  |
| N1:6303 | - | BFE0000000000000 | num:0 | num:-0 | num:0 |  |
| N1:7354 | - | A7410B321163687D | num:0 | num:-0 | num:0 |  |
| N1:7360 | - | B830A8CA20AD7DE0 | num:0 | num:-0 | num:0 |  |
| N1:7363 | - | 842A9290CC55E0F6 | num:0 | num:-0 | num:0 |  |
| N1:7364 | - | BB2FA2472DB62FCD | num:0 | num:-0 | num:0 |  |
| N1:7371 | - | B65369ADE0D16D3E | num:0 | num:-0 | num:0 |  |
| N1:7373 | - | 9365EAB8DF90B784 | num:0 | num:-0 | num:0 |  |
| N1:7379 | - | 919969203CC7B36B | num:0 | num:-0 | num:0 |  |
| N1:7383 | - | 9ACB60880C809D5A | num:0 | num:-0 | num:0 |  |
| N1:7386 | - | BBAF575CBFE0D13A | num:0 | num:-0 | num:0 |  |
| N1:7388 | - | A562E060C68779B4 | num:0 | num:-0 | num:0 |  |
| N1:7389 | - | A36D1FA731F1E3B9 | num:0 | num:-0 | num:0 |  |
| N1:7392 | - | AE872F978F1435D6 | num:0 | num:-0 | num:0 |  |
| N1:7408 | - | 8FA203806E318C9A | num:0 | num:-0 | num:0 |  |
| N1:7413 | - | 8ACB47916943E931 | num:0 | num:-0 | num:0 |  |
| N1:7415 | - | A6F127B0443F1803 | num:0 | num:-0 | num:0 |  |

## ToIntegerOrInfinity / J:JSNumberPrototype.ToIntegerOrInfinity / class a / answers -0 where the clause's integer is 0: 260990

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:1 | - | 8000000000000000 | num:0 | num:-0 | num:0 |  |
| N1:3 | - | 8000000000000001 | num:0 | num:-0 | num:0 |  |
| N1:5 | - | 800FFFFFFFFFFFFF | num:0 | num:-0 | num:0 |  |
| N1:7 | - | 8010000000000000 | num:0 | num:-0 | num:0 |  |
| N1:6303 | - | BFE0000000000000 | num:0 | num:-0 | num:0 |  |
| N1:7354 | - | A7410B321163687D | num:0 | num:-0 | num:0 |  |
| N1:7360 | - | B830A8CA20AD7DE0 | num:0 | num:-0 | num:0 |  |
| N1:7363 | - | 842A9290CC55E0F6 | num:0 | num:-0 | num:0 |  |
| N1:7364 | - | BB2FA2472DB62FCD | num:0 | num:-0 | num:0 |  |
| N1:7371 | - | B65369ADE0D16D3E | num:0 | num:-0 | num:0 |  |
| N1:7373 | - | 9365EAB8DF90B784 | num:0 | num:-0 | num:0 |  |
| N1:7379 | - | 919969203CC7B36B | num:0 | num:-0 | num:0 |  |
| N1:7383 | - | 9ACB60880C809D5A | num:0 | num:-0 | num:0 |  |
| N1:7386 | - | BBAF575CBFE0D13A | num:0 | num:-0 | num:0 |  |
| N1:7388 | - | A562E060C68779B4 | num:0 | num:-0 | num:0 |  |
| N1:7389 | - | A36D1FA731F1E3B9 | num:0 | num:-0 | num:0 |  |
| N1:7392 | - | AE872F978F1435D6 | num:0 | num:-0 | num:0 |  |
| N1:7408 | - | 8FA203806E318C9A | num:0 | num:-0 | num:0 |  |
| N1:7413 | - | 8ACB47916943E931 | num:0 | num:-0 | num:0 |  |
| N1:7415 | - | A6F127B0443F1803 | num:0 | num:-0 | num:0 |  |

## ToIntegerOrInfinity / J:JSTypedArray.ToIntegerOrInfinity / class a / answers a finite value for an infinity: 2

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:10 | - | 7FF0000000000000 | num:+Infinity | num:2147483647 | num:+Infinity |  |
| N1:11 | - | FFF0000000000000 | num:-Infinity | num:-2147483648 | num:-Infinity |  |

## ToIntegerOrInfinity / J:JSTypedArray.ToIntegerOrInfinity / class a / saturates at its type's bound: 512289

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:8 | - | 7FEFFFFFFFFFFFFF | (313 characters) | num:2147483647 | (313 characters) |  |
| N1:9 | - | FFEFFFFFFFFFFFFF | (314 characters) | num:-2147483648 | (314 characters) |  |
| N1:3322 | - | 41E0000000000000 | num:2147483648 | num:2147483647 | num:2147483648 |  |
| N1:3323 | - | 41E0000000000001 | num:2147483648 | num:2147483647 | num:2147483648 |  |
| N1:3324 | - | 41EFFFFFFFFFFFFF | num:4294967295 | num:2147483647 | num:4294967295 |  |
| N1:3325 | - | 41F0000000000000 | num:4294967296 | num:2147483647 | num:4294967296 |  |
| N1:3326 | - | 41F0000000000001 | num:4294967296 | num:2147483647 | num:4294967296 |  |
| N1:3327 | - | 41FFFFFFFFFFFFFF | num:8589934591 | num:2147483647 | num:8589934591 |  |
| N1:3328 | - | 4200000000000000 | num:8589934592 | num:2147483647 | num:8589934592 |  |
| N1:3329 | - | 4200000000000001 | num:8589934592 | num:2147483647 | num:8589934592 |  |
| N1:3330 | - | 420FFFFFFFFFFFFF | num:17179869183 | num:2147483647 | num:17179869183 |  |
| N1:3331 | - | 4210000000000000 | num:17179869184 | num:2147483647 | num:17179869184 |  |
| N1:3332 | - | 4210000000000001 | num:17179869184 | num:2147483647 | num:17179869184 |  |
| N1:3333 | - | 421FFFFFFFFFFFFF | num:34359738367 | num:2147483647 | num:34359738367 |  |
| N1:3334 | - | 4220000000000000 | num:34359738368 | num:2147483647 | num:34359738368 |  |
| N1:3335 | - | 4220000000000001 | num:34359738368 | num:2147483647 | num:34359738368 |  |
| N1:3336 | - | 422FFFFFFFFFFFFF | num:68719476735 | num:2147483647 | num:68719476735 |  |
| N1:3337 | - | 4230000000000000 | num:68719476736 | num:2147483647 | num:68719476736 |  |
| N1:3338 | - | 4230000000000001 | num:68719476736 | num:2147483647 | num:68719476736 |  |
| N1:3339 | - | 423FFFFFFFFFFFFF | num:137438953471 | num:2147483647 | num:137438953471 |  |

## ToIntegerOrInfinity / J:JSTypedArrayPrototype.ToIntegerOrInfinityIndex / class a / answers an infinity for a finite integer (its saturation sentinel): 495484

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:8 | - | 7FEFFFFFFFFFFFFF | (313 characters) | num:+Infinity | (313 characters) |  |
| N1:9 | - | FFEFFFFFFFFFFFFF | (314 characters) | num:-Infinity | (314 characters) |  |
| N1:3418 | - | 43E0000000000000 | num:9223372036854775808 | num:+Infinity | num:9223372036854775808 |  |
| N1:3419 | - | 43E0000000000001 | num:9223372036854777856 | num:+Infinity | num:9223372036854777856 |  |
| N1:3420 | - | 43EFFFFFFFFFFFFF | num:18446744073709549568 | num:+Infinity | num:18446744073709549568 |  |
| N1:3421 | - | 43F0000000000000 | num:18446744073709551616 | num:+Infinity | num:18446744073709551616 |  |
| N1:3422 | - | 43F0000000000001 | num:18446744073709555712 | num:+Infinity | num:18446744073709555712 |  |
| N1:3423 | - | 43FFFFFFFFFFFFFF | num:36893488147419099136 | num:+Infinity | num:36893488147419099136 |  |
| N1:3424 | - | 4400000000000000 | num:36893488147419103232 | num:+Infinity | num:36893488147419103232 |  |
| N1:3425 | - | 4400000000000001 | num:36893488147419111424 | num:+Infinity | num:36893488147419111424 |  |
| N1:3426 | - | 440FFFFFFFFFFFFF | num:73786976294838198272 | num:+Infinity | num:73786976294838198272 |  |
| N1:3427 | - | 4410000000000000 | num:73786976294838206464 | num:+Infinity | num:73786976294838206464 |  |
| N1:3428 | - | 4410000000000001 | num:73786976294838222848 | num:+Infinity | num:73786976294838222848 |  |
| N1:3429 | - | 441FFFFFFFFFFFFF | num:147573952589676396544 | num:+Infinity | num:147573952589676396544 |  |
| N1:3430 | - | 4420000000000000 | num:147573952589676412928 | num:+Infinity | num:147573952589676412928 |  |
| N1:3431 | - | 4420000000000001 | num:147573952589676445696 | num:+Infinity | num:147573952589676445696 |  |
| N1:3432 | - | 442FFFFFFFFFFFFF | num:295147905179352793088 | num:+Infinity | num:295147905179352793088 |  |
| N1:3433 | - | 4430000000000000 | num:295147905179352825856 | num:+Infinity | num:295147905179352825856 |  |
| N1:3434 | - | 4430000000000001 | num:295147905179352891392 | num:+Infinity | num:295147905179352891392 |  |
| N1:3435 | - | 443FFFFFFFFFFFFF | num:590295810358705586176 | num:+Infinity | num:590295810358705586176 |  |

## ToIntegerOrInfinity / J:JSValue.IntegerValue / class a / answers a finite value for an infinity: 2

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:10 | - | 7FF0000000000000 | num:+Infinity | num:2147483647 | num:+Infinity |  |
| N1:11 | - | FFF0000000000000 | num:-Infinity | num:-2147483648 | num:-Infinity |  |

## ToIntegerOrInfinity / J:JSValue.IntegerValue / class a / saturates at its type's bound: 512289

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:8 | - | 7FEFFFFFFFFFFFFF | (313 characters) | num:2147483647 | (313 characters) |  |
| N1:9 | - | FFEFFFFFFFFFFFFF | (314 characters) | num:-2147483648 | (314 characters) |  |
| N1:3322 | - | 41E0000000000000 | num:2147483648 | num:2147483647 | num:2147483648 |  |
| N1:3323 | - | 41E0000000000001 | num:2147483648 | num:2147483647 | num:2147483648 |  |
| N1:3324 | - | 41EFFFFFFFFFFFFF | num:4294967295 | num:2147483647 | num:4294967295 |  |
| N1:3325 | - | 41F0000000000000 | num:4294967296 | num:2147483647 | num:4294967296 |  |
| N1:3326 | - | 41F0000000000001 | num:4294967296 | num:2147483647 | num:4294967296 |  |
| N1:3327 | - | 41FFFFFFFFFFFFFF | num:8589934591 | num:2147483647 | num:8589934591 |  |
| N1:3328 | - | 4200000000000000 | num:8589934592 | num:2147483647 | num:8589934592 |  |
| N1:3329 | - | 4200000000000001 | num:8589934592 | num:2147483647 | num:8589934592 |  |
| N1:3330 | - | 420FFFFFFFFFFFFF | num:17179869183 | num:2147483647 | num:17179869183 |  |
| N1:3331 | - | 4210000000000000 | num:17179869184 | num:2147483647 | num:17179869184 |  |
| N1:3332 | - | 4210000000000001 | num:17179869184 | num:2147483647 | num:17179869184 |  |
| N1:3333 | - | 421FFFFFFFFFFFFF | num:34359738367 | num:2147483647 | num:34359738367 |  |
| N1:3334 | - | 4220000000000000 | num:34359738368 | num:2147483647 | num:34359738368 |  |
| N1:3335 | - | 4220000000000001 | num:34359738368 | num:2147483647 | num:34359738368 |  |
| N1:3336 | - | 422FFFFFFFFFFFFF | num:68719476735 | num:2147483647 | num:68719476735 |  |
| N1:3337 | - | 4230000000000000 | num:68719476736 | num:2147483647 | num:68719476736 |  |
| N1:3338 | - | 4230000000000001 | num:68719476736 | num:2147483647 | num:68719476736 |  |
| N1:3339 | - | 423FFFFFFFFFFFFF | num:137438953471 | num:2147483647 | num:137438953471 |  |

## ToLength / J:BuiltInsAssemblyInitializer.ToLength / class a / saturates at its type's bound: 257923

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:8 | - | 7FEFFFFFFFFFFFFF | num:9007199254740991 | num:2147483647 | num:9007199254740991 |  |
| N1:10 | - | 7FF0000000000000 | num:9007199254740991 | num:2147483647 | num:9007199254740991 |  |
| N1:3322 | - | 41E0000000000000 | num:2147483648 | num:2147483647 | num:2147483648 |  |
| N1:3323 | - | 41E0000000000001 | num:2147483648 | num:2147483647 | num:2147483648 |  |
| N1:3324 | - | 41EFFFFFFFFFFFFF | num:4294967295 | num:2147483647 | num:4294967295 |  |
| N1:3325 | - | 41F0000000000000 | num:4294967296 | num:2147483647 | num:4294967296 |  |
| N1:3326 | - | 41F0000000000001 | num:4294967296 | num:2147483647 | num:4294967296 |  |
| N1:3327 | - | 41FFFFFFFFFFFFFF | num:8589934591 | num:2147483647 | num:8589934591 |  |
| N1:3328 | - | 4200000000000000 | num:8589934592 | num:2147483647 | num:8589934592 |  |
| N1:3329 | - | 4200000000000001 | num:8589934592 | num:2147483647 | num:8589934592 |  |
| N1:3330 | - | 420FFFFFFFFFFFFF | num:17179869183 | num:2147483647 | num:17179869183 |  |
| N1:3331 | - | 4210000000000000 | num:17179869184 | num:2147483647 | num:17179869184 |  |
| N1:3332 | - | 4210000000000001 | num:17179869184 | num:2147483647 | num:17179869184 |  |
| N1:3333 | - | 421FFFFFFFFFFFFF | num:34359738367 | num:2147483647 | num:34359738367 |  |
| N1:3334 | - | 4220000000000000 | num:34359738368 | num:2147483647 | num:34359738368 |  |
| N1:3335 | - | 4220000000000001 | num:34359738368 | num:2147483647 | num:34359738368 |  |
| N1:3336 | - | 422FFFFFFFFFFFFF | num:68719476735 | num:2147483647 | num:68719476735 |  |
| N1:3337 | - | 4230000000000000 | num:68719476736 | num:2147483647 | num:68719476736 |  |
| N1:3338 | - | 4230000000000001 | num:68719476736 | num:2147483647 | num:68719476736 |  |
| N1:3339 | - | 423FFFFFFFFFFFFF | num:137438953471 | num:2147483647 | num:137438953471 |  |

## ToLength / J:JSIntl.CanonicalizeLocaleList's length / class a / saturates at its type's bound: 257644

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:8 | - | 7FEFFFFFFFFFFFFF | num:9007199254740991 | num:4294967295 | num:9007199254740991 |  |
| N1:10 | - | 7FF0000000000000 | num:9007199254740991 | num:4294967295 | num:9007199254740991 |  |
| N1:3325 | - | 41F0000000000000 | num:4294967296 | num:4294967295 | num:4294967296 |  |
| N1:3326 | - | 41F0000000000001 | num:4294967296 | num:4294967295 | num:4294967296 |  |
| N1:3327 | - | 41FFFFFFFFFFFFFF | num:8589934591 | num:4294967295 | num:8589934591 |  |
| N1:3328 | - | 4200000000000000 | num:8589934592 | num:4294967295 | num:8589934592 |  |
| N1:3329 | - | 4200000000000001 | num:8589934592 | num:4294967295 | num:8589934592 |  |
| N1:3330 | - | 420FFFFFFFFFFFFF | num:17179869183 | num:4294967295 | num:17179869183 |  |
| N1:3331 | - | 4210000000000000 | num:17179869184 | num:4294967295 | num:17179869184 |  |
| N1:3332 | - | 4210000000000001 | num:17179869184 | num:4294967295 | num:17179869184 |  |
| N1:3333 | - | 421FFFFFFFFFFFFF | num:34359738367 | num:4294967295 | num:34359738367 |  |
| N1:3334 | - | 4220000000000000 | num:34359738368 | num:4294967295 | num:34359738368 |  |
| N1:3335 | - | 4220000000000001 | num:34359738368 | num:4294967295 | num:34359738368 |  |
| N1:3336 | - | 422FFFFFFFFFFFFF | num:68719476735 | num:4294967295 | num:68719476735 |  |
| N1:3337 | - | 4230000000000000 | num:68719476736 | num:4294967295 | num:68719476736 |  |
| N1:3338 | - | 4230000000000001 | num:68719476736 | num:4294967295 | num:68719476736 |  |
| N1:3339 | - | 423FFFFFFFFFFFFF | num:137438953471 | num:4294967295 | num:137438953471 |  |
| N1:3340 | - | 4240000000000000 | num:137438953472 | num:4294967295 | num:137438953472 |  |
| N1:3341 | - | 4240000000000001 | num:137438953472 | num:4294967295 | num:137438953472 |  |
| N1:3342 | - | 424FFFFFFFFFFFFF | num:274877906943 | num:4294967295 | num:274877906943 |  |

## ToLength / J:JSTypedArray.FromShared's length / class a / saturates at its type's bound: 257923

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:8 | - | 7FEFFFFFFFFFFFFF | num:9007199254740991 | num:2147483647 | num:9007199254740991 |  |
| N1:10 | - | 7FF0000000000000 | num:9007199254740991 | num:2147483647 | num:9007199254740991 |  |
| N1:3322 | - | 41E0000000000000 | num:2147483648 | num:2147483647 | num:2147483648 |  |
| N1:3323 | - | 41E0000000000001 | num:2147483648 | num:2147483647 | num:2147483648 |  |
| N1:3324 | - | 41EFFFFFFFFFFFFF | num:4294967295 | num:2147483647 | num:4294967295 |  |
| N1:3325 | - | 41F0000000000000 | num:4294967296 | num:2147483647 | num:4294967296 |  |
| N1:3326 | - | 41F0000000000001 | num:4294967296 | num:2147483647 | num:4294967296 |  |
| N1:3327 | - | 41FFFFFFFFFFFFFF | num:8589934591 | num:2147483647 | num:8589934591 |  |
| N1:3328 | - | 4200000000000000 | num:8589934592 | num:2147483647 | num:8589934592 |  |
| N1:3329 | - | 4200000000000001 | num:8589934592 | num:2147483647 | num:8589934592 |  |
| N1:3330 | - | 420FFFFFFFFFFFFF | num:17179869183 | num:2147483647 | num:17179869183 |  |
| N1:3331 | - | 4210000000000000 | num:17179869184 | num:2147483647 | num:17179869184 |  |
| N1:3332 | - | 4210000000000001 | num:17179869184 | num:2147483647 | num:17179869184 |  |
| N1:3333 | - | 421FFFFFFFFFFFFF | num:34359738367 | num:2147483647 | num:34359738367 |  |
| N1:3334 | - | 4220000000000000 | num:34359738368 | num:2147483647 | num:34359738368 |  |
| N1:3335 | - | 4220000000000001 | num:34359738368 | num:2147483647 | num:34359738368 |  |
| N1:3336 | - | 422FFFFFFFFFFFFF | num:68719476735 | num:2147483647 | num:68719476735 |  |
| N1:3337 | - | 4230000000000000 | num:68719476736 | num:2147483647 | num:68719476736 |  |
| N1:3338 | - | 4230000000000001 | num:68719476736 | num:2147483647 | num:68719476736 |  |
| N1:3339 | - | 423FFFFFFFFFFFFF | num:137438953471 | num:2147483647 | num:137438953471 |  |

## ToLength / J:JSTypedArray.ToArrayLikeLength (1-byte elements) / class a / refuses with a RangeError an input the clause answers: 257923

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:8 | - | 7FEFFFFFFFFFFFFF | num:9007199254740991 | error:RangeError | num:9007199254740991 |  |
| N1:10 | - | 7FF0000000000000 | num:9007199254740991 | error:RangeError | num:9007199254740991 |  |
| N1:3322 | - | 41E0000000000000 | num:2147483648 | error:RangeError | num:2147483648 |  |
| N1:3323 | - | 41E0000000000001 | num:2147483648 | error:RangeError | num:2147483648 |  |
| N1:3324 | - | 41EFFFFFFFFFFFFF | num:4294967295 | error:RangeError | num:4294967295 |  |
| N1:3325 | - | 41F0000000000000 | num:4294967296 | error:RangeError | num:4294967296 |  |
| N1:3326 | - | 41F0000000000001 | num:4294967296 | error:RangeError | num:4294967296 |  |
| N1:3327 | - | 41FFFFFFFFFFFFFF | num:8589934591 | error:RangeError | num:8589934591 |  |
| N1:3328 | - | 4200000000000000 | num:8589934592 | error:RangeError | num:8589934592 |  |
| N1:3329 | - | 4200000000000001 | num:8589934592 | error:RangeError | num:8589934592 |  |
| N1:3330 | - | 420FFFFFFFFFFFFF | num:17179869183 | error:RangeError | num:17179869183 |  |
| N1:3331 | - | 4210000000000000 | num:17179869184 | error:RangeError | num:17179869184 |  |
| N1:3332 | - | 4210000000000001 | num:17179869184 | error:RangeError | num:17179869184 |  |
| N1:3333 | - | 421FFFFFFFFFFFFF | num:34359738367 | error:RangeError | num:34359738367 |  |
| N1:3334 | - | 4220000000000000 | num:34359738368 | error:RangeError | num:34359738368 |  |
| N1:3335 | - | 4220000000000001 | num:34359738368 | error:RangeError | num:34359738368 |  |
| N1:3336 | - | 422FFFFFFFFFFFFF | num:68719476735 | error:RangeError | num:68719476735 |  |
| N1:3337 | - | 4230000000000000 | num:68719476736 | error:RangeError | num:68719476736 |  |
| N1:3338 | - | 4230000000000001 | num:68719476736 | error:RangeError | num:68719476736 |  |
| N1:3339 | - | 423FFFFFFFFFFFFF | num:137438953471 | error:RangeError | num:137438953471 |  |

## ToUint16 / J:JSAtomics.TruncateToElement(Uint16, ToIntegerOperand) / class a / wraps the operand after saturating it to 64 bits, not the integer itself: 250486

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:8 | - | 7FEFFFFFFFFFFFFF | int:0 | int:65535 | int:0 |  |
| N1:3418 | - | 43E0000000000000 | int:0 | int:65535 | int:0 |  |
| N1:3419 | - | 43E0000000000001 | int:2048 | int:65535 | int:2048 |  |
| N1:3420 | - | 43EFFFFFFFFFFFFF | int:63488 | int:65535 | int:63488 |  |
| N1:3421 | - | 43F0000000000000 | int:0 | int:65535 | int:0 |  |
| N1:3422 | - | 43F0000000000001 | int:4096 | int:65535 | int:4096 |  |
| N1:3423 | - | 43FFFFFFFFFFFFFF | int:61440 | int:65535 | int:61440 |  |
| N1:3424 | - | 4400000000000000 | int:0 | int:65535 | int:0 |  |
| N1:3425 | - | 4400000000000001 | int:8192 | int:65535 | int:8192 |  |
| N1:3426 | - | 440FFFFFFFFFFFFF | int:57344 | int:65535 | int:57344 |  |
| N1:3427 | - | 4410000000000000 | int:0 | int:65535 | int:0 |  |
| N1:3428 | - | 4410000000000001 | int:16384 | int:65535 | int:16384 |  |
| N1:3429 | - | 441FFFFFFFFFFFFF | int:49152 | int:65535 | int:49152 |  |
| N1:3430 | - | 4420000000000000 | int:0 | int:65535 | int:0 |  |
| N1:3431 | - | 4420000000000001 | int:32768 | int:65535 | int:32768 |  |
| N1:3432 | - | 442FFFFFFFFFFFFF | int:32768 | int:65535 | int:32768 |  |
| N1:3433 | - | 4430000000000000 | int:0 | int:65535 | int:0 |  |
| N1:3434 | - | 4430000000000001 | int:0 | int:65535 | int:0 |  |
| N1:3435 | - | 443FFFFFFFFFFFFF | int:0 | int:65535 | int:0 |  |
| N1:3436 | - | 4440000000000000 | int:0 | int:65535 | int:0 |  |

## ToUint32 / J:JSAtomics.TruncateToElement(Uint32, ToIntegerOperand) / class a / wraps the operand after saturating it to 64 bits, not the integer itself: 254518

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:8 | - | 7FEFFFFFFFFFFFFF | int:0 | int:4294967295 | int:0 |  |
| N1:3418 | - | 43E0000000000000 | int:0 | int:4294967295 | int:0 |  |
| N1:3419 | - | 43E0000000000001 | int:2048 | int:4294967295 | int:2048 |  |
| N1:3420 | - | 43EFFFFFFFFFFFFF | int:4294965248 | int:4294967295 | int:4294965248 |  |
| N1:3421 | - | 43F0000000000000 | int:0 | int:4294967295 | int:0 |  |
| N1:3422 | - | 43F0000000000001 | int:4096 | int:4294967295 | int:4096 |  |
| N1:3423 | - | 43FFFFFFFFFFFFFF | int:4294963200 | int:4294967295 | int:4294963200 |  |
| N1:3424 | - | 4400000000000000 | int:0 | int:4294967295 | int:0 |  |
| N1:3425 | - | 4400000000000001 | int:8192 | int:4294967295 | int:8192 |  |
| N1:3426 | - | 440FFFFFFFFFFFFF | int:4294959104 | int:4294967295 | int:4294959104 |  |
| N1:3427 | - | 4410000000000000 | int:0 | int:4294967295 | int:0 |  |
| N1:3428 | - | 4410000000000001 | int:16384 | int:4294967295 | int:16384 |  |
| N1:3429 | - | 441FFFFFFFFFFFFF | int:4294950912 | int:4294967295 | int:4294950912 |  |
| N1:3430 | - | 4420000000000000 | int:0 | int:4294967295 | int:0 |  |
| N1:3431 | - | 4420000000000001 | int:32768 | int:4294967295 | int:32768 |  |
| N1:3432 | - | 442FFFFFFFFFFFFF | int:4294934528 | int:4294967295 | int:4294934528 |  |
| N1:3433 | - | 4430000000000000 | int:0 | int:4294967295 | int:0 |  |
| N1:3434 | - | 4430000000000001 | int:65536 | int:4294967295 | int:65536 |  |
| N1:3435 | - | 443FFFFFFFFFFFFF | int:4294901760 | int:4294967295 | int:4294901760 |  |
| N1:3436 | - | 4440000000000000 | int:0 | int:4294967295 | int:0 |  |

## ToUint8 / J:JSAtomics.TruncateToElement(Uint8, ToIntegerOperand) / class a / wraps the operand after saturating it to 64 bits, not the integer itself: 249454

| population | detail | input | S | arm's result | reference | vector |
|---|---|---|---|---|---|---|
| N1:8 | - | 7FEFFFFFFFFFFFFF | int:0 | int:255 | int:0 |  |
| N1:3418 | - | 43E0000000000000 | int:0 | int:255 | int:0 |  |
| N1:3419 | - | 43E0000000000001 | int:0 | int:255 | int:0 |  |
| N1:3420 | - | 43EFFFFFFFFFFFFF | int:0 | int:255 | int:0 |  |
| N1:3421 | - | 43F0000000000000 | int:0 | int:255 | int:0 |  |
| N1:3422 | - | 43F0000000000001 | int:0 | int:255 | int:0 |  |
| N1:3423 | - | 43FFFFFFFFFFFFFF | int:0 | int:255 | int:0 |  |
| N1:3424 | - | 4400000000000000 | int:0 | int:255 | int:0 |  |
| N1:3425 | - | 4400000000000001 | int:0 | int:255 | int:0 |  |
| N1:3426 | - | 440FFFFFFFFFFFFF | int:0 | int:255 | int:0 |  |
| N1:3427 | - | 4410000000000000 | int:0 | int:255 | int:0 |  |
| N1:3428 | - | 4410000000000001 | int:0 | int:255 | int:0 |  |
| N1:3429 | - | 441FFFFFFFFFFFFF | int:0 | int:255 | int:0 |  |
| N1:3430 | - | 4420000000000000 | int:0 | int:255 | int:0 |  |
| N1:3431 | - | 4420000000000001 | int:0 | int:255 | int:0 |  |
| N1:3432 | - | 442FFFFFFFFFFFFF | int:0 | int:255 | int:0 |  |
| N1:3433 | - | 4430000000000000 | int:0 | int:255 | int:0 |  |
| N1:3434 | - | 4430000000000001 | int:0 | int:255 | int:0 |  |
| N1:3435 | - | 443FFFFFFFFFFFFF | int:0 | int:255 | int:0 |  |
| N1:3436 | - | 4440000000000000 | int:0 | int:255 | int:0 |  |

